from datetime import datetime

from fastapi import APIRouter, HTTPException, Request, BackgroundTasks
from fastapi.responses import StreamingResponse, Response
from typing import Optional
from pydantic import BaseModel
import httpx
import os

from models import ROIRecord, RecordUpdate
from models.field_catalog import FIELD_CATALOG
from services.storage import (
    Conflict,
    clear_all_records,
    delete_record,
    export_csv,
    export_xlsx,
    get_all_records,
    patch_executive_summary,
    save_record,
    update_record,
)
from services.audit import get_events
from services.identity import current_username
import io
import io

router = APIRouter(prefix="/api")
HUB_API_URL = os.getenv("HUB_API_URL", "http://localhost:3501")


@router.get("/fields")
def list_fields():
    """Return the field catalog: per-field label, type, notes, and the
    ui_visible / editable / exportable / provenance flags. The frontend builds
    its Tracker columns and tooltips from this, so the UI never duplicates the
    field definitions that live in models/field_catalog.py."""
    return [f.model_dump() for f in FIELD_CATALOG]


def _sync_to_hub_bg(record_id: str, payload: dict, auth_email: str):
    import logging
    try:
        hub_resp = httpx.post(
            f"{HUB_API_URL}/v1/roi/save",
            json=payload,
            headers={"X-Alfred-User-Email": auth_email},
            timeout=10.0
        )
        hub_resp.raise_for_status()
        hub_data = hub_resp.json()
        
        update_record(
            record_id, 
            {
                "hub_roi_metric_id": hub_data.get("id"), 
                "hub_saved_at": datetime.utcnow().isoformat()
            },
            user="system",
            note="Background sync from Hub"
        )
    except Exception as e:
        logging.getLogger("roi.sync").error(f"Background sync to Hub failed: {e}")


@router.post("/records")
def create_record(record: ROIRecord, request: Request, background_tasks: BackgroundTasks):
    """Save an extracted ROI record.

    The reviewing SME is taken from Alfred's SSO identity, so the audit trail
    records who actually saved it rather than a name the client asserted."""
    if not record.hub_deliverable_id:
        raise HTTPException(
            status_code=403,
            detail="Save will not be performed since it is missing QA'd deliverable provenance available in the hub."
        )

    sso_user = current_username(request)
    if sso_user:
        record.sme = sso_user
    
    # Save locally first
    saved = save_record(record)
    
    # Dual-write: decoupled via BackgroundTasks
    if record.hub_deliverable_id:
        payload = record.model_dump()
        payload["deliverable_id"] = record.hub_deliverable_id
        auth_email = request.headers.get("X-Alfred-User-Email", "local@local")
        
        background_tasks.add_task(
            _sync_to_hub_bg, 
            record_id=saved.get("record_id"), 
            payload=payload, 
            auth_email=auth_email
        )

    return {"status": "saved", "record": saved}


@router.get("/records")
def list_records():
    """Return all saved ROI records."""
    return get_all_records()


class SummaryPatch(BaseModel):
    identifier: Optional[str] = None   # record_id, stored_name, or source_file
    source_file: Optional[str] = None  # legacy field name kept for compatibility
    executive_summary: dict


@router.patch("/records/executive-summary")
def update_executive_summary(body: SummaryPatch):
    """Attach a generated executive summary to an existing record."""
    identifier = body.identifier or body.source_file
    if not identifier:
        raise HTTPException(status_code=400, detail="identifier or source_file required")
    updated = patch_executive_summary(identifier, body.executive_summary)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Record not found for identifier: {identifier}")
    return {"status": "updated", "record_id": updated.get("record_id")}


@router.delete("/records")
def delete_all_records_endpoint():
    """Permanently delete every record (full reset). Used before a clean re-import."""
    deleted = clear_all_records()
    return {"deleted": deleted}


@router.delete("/records/{record_id}")
def delete_one_record(record_id: str, reason: str = ""):
    """Permanently delete a record. Reason must be 'duplicate' or 'error'."""
    allowed = {"duplicate", "error"}
    if reason.strip().lower() not in allowed:
        raise HTTPException(status_code=400, detail="invalid_reason")
    if not delete_record(record_id):
        raise HTTPException(status_code=404, detail="Record not found")
    return {"status": "deleted", "record_id": record_id}


@router.patch("/records/{record_id}")
def edit_record(record_id: str, update: RecordUpdate, request: Request):
    """Apply a partial edit to a stored record. Each changed field is logged to
    the append-only audit log with the editor (from SSO) and an optional note."""
    editor = current_username(request) or update.user
    try:
        updated = update_record(
            record_id, update.changes, user=editor, note=update.note,
        )
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Record not found: {record_id}")
    except ValueError as e:
        # A field name that isn't a column — a client bug, not a server fault.
        raise HTTPException(status_code=400, detail=str(e))
    except Conflict as e:
        # Well-formed but collides with another record (e.g. one ROI per hub
        # deliverable). 409 so the UI can say what to do about it.
        raise HTTPException(status_code=409, detail=str(e))
    return {"status": "updated", "record": updated}


@router.get("/records/{record_id}/audit")
def record_audit(record_id: str):
    """Return the append-only audit event history for one record (oldest-first)."""
    return get_events(record_id)


@router.get("/audit-log")
def audit_log():
    """Return the full append-only audit event history across all records."""
    return get_events()


@router.get("/records/export.csv")
def download_csv():
    """Download all records as a CSV file with the 15 Domo columns."""
    csv_content = export_csv()
    return StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=roi_export.csv"},
    )


@router.get("/records/export.xlsx")
def download_xlsx():
    """Download all records as an XLSX file with the 15 Domo columns + metadata."""
    xlsx_bytes = export_xlsx()
    filename = f"Client_ROI_Tracker_{datetime.now().date().isoformat()}.xlsx"
    return Response(
        content=xlsx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
