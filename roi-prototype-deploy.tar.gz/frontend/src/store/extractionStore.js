import { create } from 'zustand';

const useExtractionStore = create((set, get) => ({
  // Wizard Navigation
  currentStep: 0,
  setStep: (step) => set({ currentStep: step }),
  nextStep: () => set((state) => ({ currentStep: state.currentStep + 1 })),
  prevStep: () => set((state) => ({ currentStep: state.currentStep > 0 ? state.currentStep - 1 : 0 })),
  
  // Filters / Request Data
  client: '',
  publisher: '',
  year: '',
  setFilters: (filters) => set({ ...filters }),

  // Batch Processing
  batch: [],
  currentFileIndex: 0,
  setBatch: (files) => set({ batch: files, currentFileIndex: 0 }),
  nextFile: () => set((state) => {
    if (state.currentFileIndex < state.batch.length - 1) {
      return { currentFileIndex: state.currentFileIndex + 1 };
    }
    return state;
  }),

  // Extracted Data (per file)
  extractedData: {}, // Map of filename -> extracted fields
  setExtractedData: (filename, data) => set((state) => ({
    extractedData: { ...state.extractedData, [filename]: data }
  })),

  // Reset Store
  reset: () => set({
    currentStep: 0,
    client: '',
    publisher: '',
    year: '',
    batch: [],
    currentFileIndex: 0,
    extractedData: {}
  })
}));

export default useExtractionStore;
