import { EXTRACTED_FIELDS } from '../../data';

function parseDollar(str) {
  if (!str) return NaN;
  return parseFloat(String(str).replace(/[$,\s]/g, ''));
}

// Format a number as a dollar string, e.g. 42000 → "$42,000"
// Negative results are shown as "-$42,000"
function formatDollar(n) {
  if (isNaN(n) || n === 0) return null;
  const abs = Math.abs(n);
  const formatted = abs.toLocaleString('en-US', { maximumFractionDigits: 0 });
  return (n < 0 ? '-' : '') + '$' + formatted;
}

// ─── Batch aggregation helpers ────────────────────────────────────────────────
// Canonical field schema (label + variant) used to build the aggregate row.
const CANON_FIELDS = EXTRACTED_FIELDS.map(f => ({ label: f.label, variant: f.variant }));

// Sum each ROI field across every non-excluded file in the batch. A field that
// was skipped (or absent) in a file contributes 0; a field skipped in EVERY
// file stays skipped in the aggregate rather than showing a misleading $0.
function aggregateFinalFields(results) {
  const active = results.filter(r => !r.excluded && r.finalFields && r.finalFields.length);
  if (active.length === 0) return BLANK_FIELDS;
  if (active.length === 1) return active[0].finalFields;   // single file → its own values verbatim
  return CANON_FIELDS.map(({ label, variant }) => {
    let sum = 0, anyValue = false;
    active.forEach(r => {
      const f = r.finalFields.find(x => x.label === label);
      if (!f || f.flag === 'SME skipped — data not available') return;
      const n = parseDollar(f.value);
      if (!isNaN(n)) { sum += n; anyValue = true; }
    });
    if (!anyValue) {
      return { label, value: null, confidence: null, variant, source: null, flag: 'SME skipped — data not available', entryMode: null };
    }
    const value = sum === 0 ? '$0' : formatDollar(sum);
    return { label, value, confidence: null, variant, source: `Summed across ${active.length} files`, flag: null, entryMode: 'aggregated' };
  });
}

// Derive the shared client / publisher / year for a batch, flagging when files
// disagree so the Store step can warn before writing a combined record.
function deriveCommonMeta(results) {
  const metas = results.filter(r => !r.excluded).map(r => r.fileMeta || {});
  const distinct = (k, upK) => [...new Set(metas.map(m => m[k] || m[upK] || '').filter(Boolean))];
  const clients = distinct('client', 'upClient');
  const pubs    = distinct('publisher', 'upPublisher');
  const years   = distinct('year', 'upYear');
  return {
    client:      clients.length === 1 ? clients[0] : '',
    publisher:   pubs.length === 1 ? pubs[0] : '',
    year:        years.length === 1 ? years[0] : '',
    mixedClient: clients.length > 1,
    mixedYear:   years.length > 1,
  };
}

// Monetary fields that carry per-field applicability date ranges.
const MONETARY_LABELS = new Set([
  'Identified Risk', 'Identified Cost Avoidance', 'Accomplished Cost Avoidance',
  'Identified Cost Optimization', 'Accomplished Cost Optimization',
  'Realized Cost Savings', 'Annual Publisher Contract',
]);

// Build the flat ROI record the backend expects from a file's meta + fields.
// Canonical UI label → backend model key. Used for BOTH value extraction and
// per-field provenance, so the two always stay in sync.
const LABEL_TO_KEY = {
  'Identified Risk':                'identified_risk',
  'Identified Cost Avoidance':      'id_cost_avoidance',
  'Accomplished Cost Avoidance':    'acc_cost_avoidance',
  'Identified Cost Optimization':   'id_cost_optimization',
  'Accomplished Cost Optimization': 'acc_cost_optimization',
  'Realized Cost Savings':          'realized_savings',
  'Annual Publisher Contract':      'contract_spend',
};

// Build per-field provenance (source slide + confidence + alternates) from the
// script extractor's scriptData map, keyed by backend model field name. Returns
// null when there's no provenance to attach (e.g. aggregate records).
function buildFieldMeta(scriptData) {
  if (!scriptData || typeof scriptData !== 'object') return null;
  const out = {};
  for (const [label, key] of Object.entries(LABEL_TO_KEY)) {
    const s = scriptData[label];
    if (!s) continue;
    if (s.sourceSlide == null && s.confidence == null && !(s.alternates?.length)) continue;
    out[key] = {
      source_slide: s.sourceSlide ?? null,
      confidence:   s.confidence ?? null,
      alternates:   (s.alternates || []).map(a => ({ value: a.value, confidence: a.confidence })),
    };
  }
  return Object.keys(out).length ? out : null;
}

function buildRecord(meta, fields, sme, scriptData = null) {
  const getValue = (label) => {
    const f = fields.find(x => x.label === label);
    const n = parseDollar(f?.value);
    return isNaN(n) ? null : n;
  };
  return {
    client:                meta?.client    || meta?.upClient    || '',
    publisher:             meta?.publisher || meta?.upPublisher || '',
    year:                  parseInt(meta?.year || meta?.upYear || new Date().getFullYear()),
    month:                 meta?.month          || null,
    currency:              meta?.currency         || 'USD',
    date_delivered:        meta?.date_delivered   || null,
    applicable_from:       meta?.applicable_from  || null,
    applicable_to:         meta?.applicable_to    || null,
    identified_risk:       getValue('Identified Risk'),
    id_cost_avoidance:     getValue('Identified Cost Avoidance'),
    acc_cost_avoidance:    getValue('Accomplished Cost Avoidance'),
    id_cost_optimization:  getValue('Identified Cost Optimization'),
    acc_cost_optimization: getValue('Accomplished Cost Optimization'),
    realized_savings:      getValue('Realized Cost Savings'),
    contract_spend:        getValue('Annual Publisher Contract'),
    confidence:            fields.find(x => x.confidence != null)?.confidence ?? null,
    source_file:           meta?.filename || meta?.name || meta?.file_path || '',
    stored_name:           meta?.stored_name || '',
    sme:                   sme || '',
    field_meta:            buildFieldMeta(scriptData),
    field_dates: (() => {
      if (!meta?.fieldDates) return null;
      const entries = Object.entries(meta.fieldDates)
        .filter(([, d]) => d?.from || d?.to)
        .map(([label, d]) => [LABEL_TO_KEY[label], d])
        .filter(([key]) => key);
      return entries.length ? Object.fromEntries(entries) : null;
    })(),
  };
}

// ─── Script extractor (/api/roar/extract) → Compare "Script" column ───────────
// Maps the extractor's roi_fields keys to the canonical Compare labels.
// Note: 'identified_cost_savings' is intentionally omitted — the deterministic
// script extractor does not return it by design (it is not present in standard
// ROAR documents), so there is no key to map here.
const ROAR_KEY_TO_LABEL = {
  identified_risk:                'Identified Risk',
  identified_cost_avoidance:      'Identified Cost Avoidance',
  accomplished_cost_avoidance:    'Accomplished Cost Avoidance',
  identified_cost_optimization:   'Identified Cost Optimization',
  accomplished_cost_optimization: 'Accomplished Cost Optimization',
  realized_cost_savings:          'Realized Cost Savings',
};

// Shape the raw extractor response into { [label]: { value, confidence, uncertain, alternates } }
// for the Compare screen. A field is "uncertain" when the extractor found competing
// candidate values (alternates) — that's what flags the file for SME scrutiny.
function buildScriptData(roar) {
  const fields = roar?.roi_fields || {};
  const out = {};
  for (const [key, label] of Object.entries(ROAR_KEY_TO_LABEL)) {
    const f = fields[key];
    if (!f) continue;
    const alternates = Array.isArray(f.alternates) ? f.alternates : [];
    out[label] = {
      value: formatDollar(f.value),
      confidence: f.confidence,
      uncertain: alternates.length > 0,
      alternates: alternates.map(a => ({ value: formatDollar(a.value), confidence: a.confidence })),
      capacity: f.capacity,
      sourceSlide: f.source_slide,
      raw: f.raw ?? null,
    };
  }
  return out;
}


export { parseDollar, formatDollar, aggregateFinalFields, deriveCommonMeta, buildFieldMeta, buildRecord, buildScriptData, MONETARY_LABELS };
