import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createPortal } from 'react-dom';
import Badge from '../Badge';
import { SlideStack, SlideCarousel } from './SlideCarousel';
import { extractROAR, extractFromFile, getRecords, saveRecord } from '../../services/api';
import { EXTRACTED_FIELDS } from '../../data';
import { getAllowedPublishers } from '../../services/workstreams';
import { getHubContext } from '../../services/hubContext';
import { parseDollar, formatDollar, aggregateFinalFields, deriveCommonMeta, buildFieldMeta, buildRecord, buildScriptData, MONETARY_LABELS } from './helpers';

// ─── Publisher picker ─────────────────────────────────────────────────────────
// ROI is reported per publisher, but the hub hands us a workstream (its team).
// When that workstream maps to a known publisher set we constrain the choice to
// it and preselect the default; otherwise we fall back to a free-text field with
// suggestions, so an unmapped workstream never blocks a review.
function PublisherField({ value, onChange, placeholder }) {
  const [options, setOptions] = useState([]);
  const [mapped, setMapped] = useState(false);

  useEffect(() => {
    let active = true;
    const ctx = getHubContext();
    getAllowedPublishers(ctx?.workstream).then(res => {
      if (!active) return;
      const list = res.publishers || [];
      setOptions(list);
      setMapped(Boolean(res.mapped));
      // Only fill a blank field — never overwrite what the extractor found.
      if (!value && res.mapped && list.length) {
        onChange((list.find(p => p.is_default) || list[0]).publisher);
      }
    });
    return () => { active = false; };
    // Runs once: the hub handoff is fixed for the session.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (mapped && options.length) {
    return (
      <select
        className="compare-record-detail-input"
        value={value || ''}
        onChange={e => onChange(e.target.value)}
      >
        {!value && <option value="">Select a publisher…</option>}
        {options.map(o => (
          <option key={o.publisher} value={o.publisher}>{o.publisher}</option>
        ))}
      </select>
    );
  }

  return (
    <>
      <input
        type="text"
        list="known-publishers"
        className="compare-record-detail-input"
        value={value || ''}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
      />
      <datalist id="known-publishers">
        {options.map(o => <option key={o.publisher} value={o.publisher} />)}
      </datalist>
    </>
  );
}

// ─── Blank field template ─────────────────────────────────────────────────────
// The canonical 7 ROI fields with no data — derived from EXTRACTED_FIELDS so the
// field labels and variant colors stay in one place (its schema), but every value
// is nulled. Used as the honest empty state when extraction fails or when a step
// is reached without any extracted data, instead of substituting mock numbers.
const BLANK_FIELDS = EXTRACTED_FIELDS.map(f => ({
  ...f,
  value: null,
  confidence: null,
  source: null,
  flag: null,
  entryMode: null,
}));

const ROI_FIELD_META = {
  'Identified Risk': {
    definition: 'Quantified financial exposure due to non-compliance with software licensing or contractual terms.',
    questions: [
      'Which software publisher(s) or product(s) have a compliance shortfall?',
      'What is the unit cost (price per license)?',
      'How many licenses is the client entitled to per contract?',
      'How many licenses are currently deployed or in use?',
      'What contract period or date does this exposure apply to?',
    ],
    // 'text' | 'currency' | 'number' | 'date'
    questionTypes: ['text', 'currency', 'number', 'number', 'date'],
    formula: 'Calculated as: (Deployed Licenses − Entitled Licenses) × Unit Cost',
    // answers[1]=unitCost  answers[2]=entitled  answers[3]=deployed
    compute(answers) {
      const unitCost  = parseDollar(answers[1]);
      const entitled  = parseFloat(answers[2]);
      const deployed  = parseFloat(answers[3]);
      if (isNaN(unitCost) || isNaN(entitled) || isNaN(deployed)) return null;
      return formatDollar((deployed - entitled) * unitCost);
    },
  },
  'Identified Cost Avoidance': {
    definition: 'Potential unbudgeted costs that can be prevented through proactive compliance. Measurable in avoided liabilities. Client has NOT yet acted.',
    questions: [
      'What over-deployment or compliance gap did you identify that the client could remediate?',
      'How many excess licenses could be removed?',
      'What is the unit cost of those licenses?',
      'Can the client remediate this within their current contract terms?',
    ],
    questionTypes: ['text', 'number', 'currency', 'text'],
    formula: 'Calculated as: Excess Licenses × Unit Cost',
    // answers[1]=excessLicenses  answers[2]=unitCost
    compute(answers) {
      const excess    = parseFloat(answers[1]);
      const unitCost  = parseDollar(answers[2]);
      if (isNaN(excess) || isNaN(unitCost)) return null;
      return formatDollar(excess * unitCost);
    },
  },
  'Accomplished Cost Avoidance': {
    definition: 'The quantified result of actions taken to prevent unbudgeted costs. Requires client action to accomplish.',
    questions: [
      'What action did the client take (e.g. removed deployments, reduced installs)?',
      'How many licenses were removed or remediated?',
      'What is the unit cost of those licenses?',
      'What is the confirmation or evidence of the action taken?',
    ],
    questionTypes: ['text', 'number', 'currency', 'text'],
    formula: 'Calculated as: Remediated Licenses × Unit Cost',
    // answers[1]=remediatedLicenses  answers[2]=unitCost
    compute(answers) {
      const remediated = parseFloat(answers[1]);
      const unitCost   = parseDollar(answers[2]);
      if (isNaN(remediated) || isNaN(unitCost)) return null;
      return formatDollar(remediated * unitCost);
    },
  },
  'Identified Cost Optimization': {
    definition: 'Opportunities to reduce software, hardware, or cloud expenses through license optimization, contract negotiations, or strategic adjustments. Client has NOT yet acted.',
    questions: [
      'What optimization opportunity did you identify?',
      'How many licenses are surplus to actual need?',
      'What is the unit cost or annual contract value of those licenses?',
      'Is a contract mechanism available to right-size (e.g. true-down clause, renewal timing)?',
    ],
    questionTypes: ['text', 'number', 'currency', 'text'],
    formula: 'Calculated as: Surplus Licenses × Unit Cost, or estimated contract delta',
    // answers[1]=surplusLicenses  answers[2]=unitCost
    compute(answers) {
      const surplus   = parseFloat(answers[1]);
      const unitCost  = parseDollar(answers[2]);
      if (isNaN(surplus) || isNaN(unitCost)) return null;
      return formatDollar(surplus * unitCost);
    },
  },
  'Accomplished Cost Optimization': {
    definition: 'Verified cost reductions through renegotiations, contract adjustments, or technology shifts. Requires client action to accomplish.',
    // This field supports two input modes — pick one using the toggle on the form.
    modes: {
      contractValue: {
        label: 'Contract value change',
        questions: [
          'What specific action was taken?',
          'What was the original contract value?',
          'What is the new contract value after the change?',
          'What is the effective date of the change?',
        ],
        questionTypes: ['text', 'currency', 'currency', 'date'],
        formula: 'Calculated as: Original Contract Value − New Contract Value',
        // answers[1]=originalValue  answers[2]=newValue
        compute(answers) {
          const original = parseDollar(answers[1]);
          const newVal   = parseDollar(answers[2]);
          if (isNaN(original) || isNaN(newVal)) return null;
          return formatDollar(original - newVal);
        },
      },
      licenseCount: {
        label: 'License count change',
        questions: [
          'What specific action was taken?',
          'What was the original license count?',
          'What is the new license count after the change?',
          'What is the cost per license?',
          'What is the effective date of the change?',
        ],
        questionTypes: ['text', 'number', 'number', 'currency', 'date'],
        formula: 'Calculated as: (Original Count − New Count) × Cost Per License',
        // answers[1]=originalCount  answers[2]=newCount  answers[3]=costPerLicense
        compute(answers) {
          const original        = parseFloat(answers[1]);
          const newCount        = parseFloat(answers[2]);
          const costPerLicense  = parseDollar(answers[3]);
          if (isNaN(original) || isNaN(newCount) || isNaN(costPerLicense)) return null;
          return formatDollar((original - newCount) * costPerLicense);
        },
      },
    },
  },
  'Identified Cost Savings': {
    definition: 'A hard-dollar reduction opportunity has been identified but not yet realized.',
    questions: [
      'What is the current annual spend for this publisher or product?',
      'What specific mechanism would generate savings?',
      'What is the projected reduced spend if the opportunity is acted upon?',
    ],
    questionTypes: ['currency', 'text', 'currency'],
    formula: 'Calculated as: Current Spend − Projected Spend',
    // answers[0]=currentSpend  answers[2]=projectedSpend
    compute(answers) {
      const current   = parseDollar(answers[0]);
      const projected = parseDollar(answers[2]);
      if (isNaN(current) || isNaN(projected)) return null;
      return formatDollar(current - projected);
    },
  },
  'Realized Cost Savings': {
    definition: 'Hard-dollar savings reflected in budgets or financial statements due to negotiated reductions or decreased expenses.',
    questions: [
      "What was the client's spend for this publisher/product in the prior comparable period?",
      'What is the confirmed spend for this period?',
      'What drove the reduction?',
      'Is this reflected in an invoice, PO, or budget document?',
    ],
    questionTypes: ['currency', 'currency', 'text', 'text'],
    formula: 'Calculated as: Prior Period Spend − Current Period Spend',
    // answers[0]=priorSpend  answers[1]=currentSpend
    compute(answers) {
      const prior   = parseDollar(answers[0]);
      const current = parseDollar(answers[1]);
      if (isNaN(prior) || isNaN(current)) return null;
      return formatDollar(prior - current);
    },
  },
};
// ─── Claude extractor response → canonical 7-field array ──────────────────────
// When no data came back, fall back to the honest blank template (no mock numbers).
function buildClaudeFields(extractedData) {
  if (!extractedData) return BLANK_FIELDS;
  const fmt = (n) => n != null ? `$${Number(n).toLocaleString()}` : null;
  const fallbackConf = extractedData?.overall_confidence ?? extractedData?.confidence ?? null;
  // Support both new per-field format {value, confidence, source} and old flat format
  const fieldVal  = (key) => { const v = extractedData[key]; return (v && typeof v === 'object') ? v.value  : v; };
  const fieldConf = (key) => { const v = extractedData[key]; return (v && typeof v === 'object') ? (v.confidence ?? null) : fallbackConf; };
  const fieldSrc  = (key) => { const v = extractedData[key]; return (v && typeof v === 'object') ? (v.source  ?? null) : null; };
  const fieldSlide= (key) => { const v = extractedData[key]; return (v && typeof v === 'object') ? (v.source_slide ?? null) : null; };
  const entry     = (key) => fieldVal(key) != null ? 'extracted' : null;
  return [
    { label: 'Identified Risk',                value: fmt(fieldVal('identified_risk')),         variant: 'green', confidence: fieldConf('identified_risk'),         source: fieldSrc('identified_risk'),         source_slide: fieldSlide('identified_risk'),         flag: null, entryMode: entry('identified_risk')         },
    { label: 'Identified Cost Avoidance',      value: fmt(fieldVal('id_cost_avoidance')),       variant: 'green', confidence: fieldConf('id_cost_avoidance'),       source: fieldSrc('id_cost_avoidance'),       source_slide: fieldSlide('id_cost_avoidance'),       flag: null, entryMode: entry('id_cost_avoidance')       },
    { label: 'Accomplished Cost Avoidance',    value: fmt(fieldVal('acc_cost_avoidance')),      variant: 'green', confidence: fieldConf('acc_cost_avoidance'),      source: fieldSrc('acc_cost_avoidance'),      source_slide: fieldSlide('acc_cost_avoidance'),      flag: null, entryMode: entry('acc_cost_avoidance')      },
    { label: 'Identified Cost Optimization',   value: fmt(fieldVal('id_cost_optimization')),    variant: 'blue',  confidence: fieldConf('id_cost_optimization'),    source: fieldSrc('id_cost_optimization'),    source_slide: fieldSlide('id_cost_optimization'),    flag: null, entryMode: entry('id_cost_optimization')    },
    { label: 'Accomplished Cost Optimization', value: fmt(fieldVal('acc_cost_optimization')),   variant: 'blue',  confidence: fieldConf('acc_cost_optimization'),   source: fieldSrc('acc_cost_optimization'),   source_slide: fieldSlide('acc_cost_optimization'),   flag: null, entryMode: entry('acc_cost_optimization')   },
    { label: 'Identified Cost Savings',        value: fmt(fieldVal('identified_cost_savings')), variant: 'green', confidence: fieldConf('identified_cost_savings'), source: fieldSrc('identified_cost_savings'), source_slide: fieldSlide('identified_cost_savings'), flag: null, entryMode: entry('identified_cost_savings') },
    { label: 'Realized Cost Savings',          value: fmt(fieldVal('realized_savings')),        variant: 'green', confidence: fieldConf('realized_savings'),        source: fieldSrc('realized_savings'),        source_slide: fieldSlide('realized_savings'),        flag: null, entryMode: entry('realized_savings')        },
  ];
}

// ─── Screen 3: Extract — per-file missing-field review (modal + Q&A fallback) ──
// Extraction itself now runs up front in BatchExtract; this screen receives the
// pre-extracted data for ONE file and lets the SME fill in or skip any missing
// fields before that file moves on to Compare.
function ScreenExtract({ selectedFile, extractedData = null, batchInfo = null, onNext }) {
  // Modal + fallback form state.
  // Initialize showModal synchronously so the overlay is present on the very
  // first paint when fields are missing — otherwise the card paints once and the
  // overlay pops in a frame later, making the dialog appear to jump.
  const [showModal, setShowModal]         = useState(
    () => buildClaudeFields(extractedData).some(f => !f.value)
  );
  const [fallbackMode, setFallbackMode]   = useState(false);
  const [fallbackIndex, setFallbackIndex] = useState(0);
  // answers keyed by field label — each value is an array of strings (one per question)
  const [fallbackAnswers, setFallbackAnswers] = useState({});
  // working copy of fields that will be passed to Store
  const [mergedFields, setMergedFields] = useState(null);
  // active mode key for multi-mode fields (e.g. Accomplished Cost Optimization)
  const [modeSelections, setModeSelections] = useState({});
  // direct value entry — SME types a known dollar amount instead of going through Q&A
  const [directValues, setDirectValues] = useState({});   // { [fieldLabel]: string } raw numeric
  const [directNotes,  setDirectNotes]  = useState({});   // { [fieldLabel]: string } optional commentary
  // Q&A accordion — collapsed by default, resets when advancing to next field
  const [qaOpen, setQaOpen] = useState(false);

  // Pre-extracted data arrives via props; map it to the canonical 7-field array.
  // Falls back to the honest blank template when the extractor returned nothing.
  const displayFields = buildClaudeFields(extractedData);

  const confidence = extractedData?.confidence ?? null;
  const confClass = c => c >= 90 ? 'conf-high' : c >= 75 ? 'conf-mid' : 'conf-low';

  // Fields with no extracted value
  const missingFields = displayFields.filter(f => !f.value);

  // ── Modal handlers ──
  const handleSkipAll = () => {
    const skipped = displayFields.map(f =>
      f.value ? f : { ...f, value: null, flag: 'SME skipped — data not available', entryMode: null }
    );
    setShowModal(false);
    onNext(skipped);
  };

  const handleFillIn = () => {
    setShowModal(false);
    setFallbackIndex(0);
    setFallbackAnswers(
      Object.fromEntries(missingFields.map(f => {
        const fieldMeta    = ROI_FIELD_META[f.label];
        // Mode-based fields (e.g. Accomplished Cost Optimization) have no top-level
        // questions array — initialize using the first mode's question count instead.
        const firstModeKey = fieldMeta?.modes ? Object.keys(fieldMeta.modes)[0] : null;
        const questionCount = firstModeKey
          ? fieldMeta.modes[firstModeKey].questions.length
          : (fieldMeta?.questions?.length || 0);
        return [f.label, Array(questionCount).fill('')];
      }))
    );
    setDirectValues(Object.fromEntries(missingFields.map(f => [f.label, ''])));
    setDirectNotes(Object.fromEntries(missingFields.map(f => [f.label, ''])));
    setFallbackMode(true);
  };

  // ── Fallback form handlers ──
  const advanceFallback = (updatedFields) => {
    if (fallbackIndex < missingFields.length - 1) {
      setFallbackIndex(i => i + 1);
      setMergedFields(updatedFields);
      setQaOpen(false);
    } else {
      // All missing fields handled — go to Store
      setFallbackMode(false);
      onNext(updatedFields);
    }
  };

  const handleFallbackNext = () => {
    const field          = missingFields[fallbackIndex];
    // Direct entry takes priority over the Q&A computation path
    const rawDirect      = (directValues[field.label] || '').trim();
    const directNum      = parseFloat(rawDirect);
    const hasDirectValue = !isNaN(directNum) && rawDirect !== '';

    let computed;
    if (hasDirectValue) {
      computed = formatDollar(directNum);
    } else {
      const answers       = fallbackAnswers[field.label] || [];
      const meta          = ROI_FIELD_META[field.label];
      const activeModeKey = modeSelections[field.label] || (meta?.modes ? Object.keys(meta.modes)[0] : null);
      const resolvedMeta  = activeModeKey ? meta.modes[activeModeKey] : meta;
      computed = resolvedMeta?.compute ? resolvedMeta.compute(answers) : null;
    }

    const updated = (mergedFields || displayFields).map(f =>
      f.label === field.label
        ? { ...f, value: computed, entryMode: computed ? 'manual' : null, flag: computed ? null : 'SME skipped — data not available' }
        : f
    );
    advanceFallback(updated);
  };

  const handleFallbackSkip = () => {
    const field = missingFields[fallbackIndex];
    const updated = (mergedFields || displayFields).map(f =>
      f.label === field.label
        ? { ...f, value: null, entryMode: null, flag: 'SME skipped — data not available' }
        : f
    );
    advanceFallback(updated);
  };

  const updateAnswer = (qIdx, val) => {
    const field = missingFields[fallbackIndex];
    setFallbackAnswers(prev => {
      const arr = [...(prev[field.label] || [])];
      arr[qIdx] = val;
      return { ...prev, [field.label]: arr };
    });
  };

  // ── Render: fallback form ──
  if (fallbackMode) {
    const field      = missingFields[fallbackIndex];
    const meta       = ROI_FIELD_META[field.label] || { definition: '', questions: [], questionTypes: [], formula: '' };
    const answers    = fallbackAnswers[field.label] || [];

    // If this field has multiple modes, resolve the active mode's sub-config
    const activeModeKey = modeSelections[field.label] || (meta.modes ? Object.keys(meta.modes)[0] : null);
    const activeMeta    = activeModeKey ? meta.modes[activeModeKey] : meta;

    const handleModeChange = (modeKey) => {
      setModeSelections(prev => ({ ...prev, [field.label]: modeKey }));
      // Reset answers for this field so stale answer indices don't bleed across modes
      setFallbackAnswers(prev => ({
        ...prev,
        [field.label]: Array(meta.modes[modeKey].questions.length).fill(''),
      }));
    };

    const liveComputed = activeMeta.compute ? activeMeta.compute(answers) : null;

    return (
      <div className="card">
        {batchInfo?.total > 1 && (
          <div className="batch-progress">
            <i className="ti ti-files" aria-hidden="true" />
            File {batchInfo.index + 1} of {batchInfo.total}{batchInfo.name ? ` — ${batchInfo.name}` : ''}
          </div>
        )}
        <div className="fallback-progress">
          <i className="ti ti-edit" aria-hidden="true" />
          Field {fallbackIndex + 1} of {missingFields.length} — Manual Entry
        </div>
        <div className="card-title">{field.label}</div>
        <p className="fallback-field-def">{meta.definition}</p>

        <div className="fallback-two-col">

          {/* ── Left: Direct Value Entry ───────────────────────────────────── */}
          <div className="fallback-direct-section">
            <div className="fallback-direct-header">
              <i className="ti ti-currency-dollar" aria-hidden="true" />
              <div>
                <div className="fallback-direct-title">Enter a Known Value</div>
                <div className="fallback-direct-sub">Already have the ROI figure? Type it here.</div>
              </div>
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="fb-direct-val">Dollar Amount</label>
              <div className="input-prefix-group">
                <span className="input-prefix">$</span>
                <input
                  id="fb-direct-val"
                  type="number"
                  min="0"
                  step="any"
                  placeholder="0"
                  value={directValues[field.label] || ''}
                  onChange={e => setDirectValues(prev => ({ ...prev, [field.label]: e.target.value }))}
                />
              </div>
            </div>
            <div className="field-group field-group-flush">
              <label className="field-label" htmlFor="fb-direct-notes">
                Commentary Notes <span className="fallback-optional-label">(optional)</span>
              </label>
              <textarea
                id="fb-direct-notes"
                className="fallback-notes-input"
                placeholder="Add any context or source reference for this value…"
                value={directNotes[field.label] || ''}
                onChange={e => setDirectNotes(prev => ({ ...prev, [field.label]: e.target.value }))}
              />
            </div>
          </div>

          {/* ── Right: Q&A Collapsible ─────────────────────────────────────── */}
          <div className="fallback-qa-section">
            <button
              className="fallback-qa-toggle"
              onClick={() => setQaOpen(o => !o)}
              aria-expanded={qaOpen}
            >
              <i className={`ti ti-chevron-${qaOpen ? 'up' : 'down'}`} aria-hidden="true" />
              Calculate from Q&amp;A
              <span className="fallback-qa-toggle-hint">
                {qaOpen ? 'Hide questions' : 'Expand to calculate'}
              </span>
            </button>

            {qaOpen && (
              <div className="fallback-qa-body">
                {/* Mode toggle — only shown for multi-mode fields */}
                {meta.modes && (
                  <div className="fallback-mode-toggle">
                    {Object.entries(meta.modes).map(([key, modeMeta]) => (
                      <button
                        key={key}
                        className={`fallback-mode-btn ${activeModeKey === key ? 'active' : ''}`}
                        onClick={() => handleModeChange(key)}
                      >
                        {modeMeta.label}
                      </button>
                    ))}
                  </div>
                )}

                <div className="fallback-questions">
                  {activeMeta.questions.map((q, qi) => {
                    const qType = (activeMeta.questionTypes && activeMeta.questionTypes[qi]) || 'text';
                    const val   = answers[qi] || '';
                    return (
                      <div className="fallback-question" key={qi}>
                        <label className="field-label" htmlFor={`fb-q-${qi}`}>{q}</label>
                        {qType === 'currency' ? (
                          <div className="input-prefix-group">
                            <span className="input-prefix">$</span>
                            <input
                              id={`fb-q-${qi}`}
                              type="number"
                              min="0"
                              step="any"
                              placeholder="0"
                              value={val}
                              onChange={e => updateAnswer(qi, e.target.value)}
                            />
                          </div>
                        ) : qType === 'date' ? (
                          <input
                            id={`fb-q-${qi}`}
                            type="date"
                            value={val}
                            onChange={e => updateAnswer(qi, e.target.value)}
                          />
                        ) : qType === 'number' ? (
                          <input
                            id={`fb-q-${qi}`}
                            type="number"
                            min="0"
                            step="1"
                            placeholder="0"
                            value={val}
                            onChange={e => updateAnswer(qi, e.target.value)}
                          />
                        ) : (
                          <input
                            id={`fb-q-${qi}`}
                            type="text"
                            placeholder="Optional — leave blank to skip"
                            value={val}
                            onChange={e => updateAnswer(qi, e.target.value)}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="fallback-formula">{activeMeta.formula}</div>

                {liveComputed && (
                  <div className="fallback-computed-preview">
                    <i className="ti ti-calculator" aria-hidden="true" />
                    Calculated value: <strong>{liveComputed}</strong>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>

        <div className="btn-row">
          <button className="btn ghost" onClick={handleFallbackSkip}>
            <i className="ti ti-forward" aria-hidden="true" /> Skip this field
          </button>
          <button className="btn primary" onClick={handleFallbackNext}>
            {fallbackIndex < missingFields.length - 1 ? 'Next Field' : 'Review & Store'}
            <i className="ti ti-arrow-right" aria-hidden="true" />
          </button>
        </div>
      </div>
    );
  }

  // ── Render: extracted results + missing-field review ──
  return (
    <div className="card">
      {batchInfo?.total > 1 && (
        <div className="batch-progress">
          <i className="ti ti-files" aria-hidden="true" />
          File {batchInfo.index + 1} of {batchInfo.total}{batchInfo.name ? ` — ${batchInfo.name}` : ''}
        </div>
      )}
      <div className="card-title">
        <i className="ti ti-cpu" aria-hidden="true" />
        ROI Extraction{selectedFile?.name ? ` — ${selectedFile.name}` : ''}
      </div>
      <p className="extract-sub">
        Review the extracted values. Fill in or skip anything the extractor could not find.
      </p>

      {(
        <div className="extract-results">
          <div className="extract-results-title">Extracted Fields</div>
          <div className="extract-chips">
            {displayFields.map(f => (
              <div className={`extract-chip ${!f.value ? 'missing' : ''}`} key={f.label}>
                <span className="extract-chip-label">{f.label.split(' ')[0]}:</span>
                <strong>{f.value ?? <span className="extract-chip-missing">not found</span>}</strong>
              </div>
            ))}
            <div className="extract-chip">
              <span className="extract-chip-label">Confidence:</span>
              <strong className={confidence != null ? confClass(confidence) : ''}>
                {confidence != null ? `${confidence}%` : '—'}
              </strong>
            </div>
          </div>
          {!showModal && missingFields.length === 0 && (
            <div className="btn-row">
              <button className="btn primary" onClick={() => onNext(displayFields)}>
                Continue to Compare <i className="ti ti-arrow-right" aria-hidden="true" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* ── Missing-fields modal ── */}
      {/* Rendered through a portal to document.body so it escapes the card's
          screenIn entrance animation. A `transform` on any ancestor makes a
          position:fixed child anchor to that ancestor instead of the viewport,
          which caused the overlay to appear offset and then jump to center when
          the animation finished. The portal keeps it viewport-centered from the
          first frame, so the overlay and dialog appear together. */}
      {showModal && createPortal(
        <div className="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <div className="modal-box">
            <div className="modal-icon">
              <i className="ti ti-alert-circle" aria-hidden="true" />
            </div>
            <div className="modal-title" id="modal-title">
              Some fields couldn't be extracted from your documents. Would you like to fill them in manually?
            </div>
            <ul className="modal-missing-list">
              {missingFields.map(f => (
                <li key={f.label}>
                  <i className="ti ti-point-filled" aria-hidden="true" />
                  {f.label}
                </li>
              ))}
            </ul>
            <div className="modal-btn-row">
              <button className="btn ghost" onClick={handleSkipAll}>
                Skip — Continue to Store
              </button>
              <button className="btn primary" onClick={handleFillIn}>
                <i className="ti ti-pencil" aria-hidden="true" /> Fill In Missing Fields
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}

// ─── Screen 3 (host): Batch Extract ───────────────────────────────────────────
// Runs the deterministic script extractor + Claude AI across EVERY file in the
// batch up front, on one progress screen. Each file's results are collected and
// handed to the per-file review (Compare) step. A single-file batch behaves like
// the original flow — one file processed, one progress row.
function BatchExtract({ files = [], onComplete }) {
  const [statuses, setStatuses] = useState(() => files.map(() => 'pending'));
  const [done, setDone] = useState(false);
  const resultsRef = useRef([]);

  useEffect(() => {
    let cancelled = false;

    async function run() {
      const results = [];
      for (let i = 0; i < files.length; i++) {
        if (cancelled) return;
        setStatuses(prev => prev.map((s, idx) => idx === i ? 'running' : s));

        const file = files[i];
        let extractedData = null;
        let scriptData = null;
        const tasks = [];

        // Script extractor — only runs when a raw File is available (uploads and
        // folder-scanned files); skipped on the SharePoint-search path.
        let scriptMeta = null;
        if (file?.file) {
          tasks.push(
            extractROAR(file.file)
              .then(roar => {
                scriptData = buildScriptData(roar);
                scriptMeta = {
                  client_scope_name: roar?.client_scope_name || null,
                  applicable_from:   roar?.applicable_from || null,
                  applicable_to:     roar?.applicable_to || null,
                  publisher:         roar?.publisher || null,
                };
              })
              .catch(() => {})
          );
        }

        // Claude AI extractor — pass the whole file object so it can use
        // id / stored_name / path, falling back to the filename.
        const fileRef = (file?.path || file?.id || file?.stored_name) ? file : (file?.name || '');
        tasks.push(
          extractFromFile(fileRef)
            .then(res => { extractedData = res.data || res; })
            .catch(() => {})
        );

        await Promise.all(tasks);
        if (cancelled) return;

        results.push({ fileMeta: file, extractedData, scriptData, scriptMeta });
        setStatuses(prev => prev.map((s, idx) => idx === i ? 'done' : s));
        await new Promise(r => setTimeout(r, 150));
      }
      if (!cancelled) {
        resultsRef.current = results;
        setDone(true);
      }
    }

    run();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!files.length) {
    return (
      <div className="card">
        <div className="card-title">
          <i className="ti ti-cpu" aria-hidden="true" /> ROI Extraction
        </div>
        <p className="extract-sub">No files selected. Go back and choose one or more files to extract.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <div className="card-title">
        <i className="ti ti-cpu" aria-hidden="true" /> ROI Extraction
      </div>
      <p className="extract-sub">
        Running the script extractor and Claude AI across {files.length} file{files.length !== 1 ? 's' : ''}…
      </p>

      <div className="extract-steps">
        {files.map((f, i) => {
          const status = statuses[i];
          return (
            <div className={`extract-step ${status}`} key={i}>
              <div className="extract-step-icon">
                {status === 'done'    && <i className="ti ti-check" aria-hidden="true" />}
                {status === 'running' && <i className="ti ti-loader-2 spinning" aria-hidden="true" />}
                {status === 'pending' && <i className="ti ti-circle" aria-hidden="true" />}
              </div>
              <span className="extract-step-label">{f.name || `File ${i + 1}`}</span>
              {status === 'done'    && <Badge color="green"><i className="ti ti-check" /> Done</Badge>}
              {status === 'running' && <Badge color="blue">Running…</Badge>}
              {status === 'pending' && <Badge color="navy">Pending</Badge>}
            </div>
          );
        })}
      </div>

      {done && (
        <div className="btn-row">
          <button className="btn primary" onClick={() => onComplete(resultsRef.current)}>
            Review {files.length > 1 ? `${files.length} Files` : 'File'} <i className="ti ti-arrow-right" aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  );
}
// ─── Field Card with View Source ──────────────────────────────────────────────
function FieldCard({ field, currentValue, isEditing, onStartEdit, onCommit, onKeyDown }) {
  const [sourceOpen, setSourceOpen] = useState(false);
  const isSkipped  = field.flag === 'SME skipped — data not available';
  const isManual   = field.entryMode === 'manual';
  const isEdited   = !isSkipped && currentValue !== field.value;
  const confClass  = field.confidence >= 90 ? 'conf-high' : field.confidence >= 75 ? 'conf-mid' : 'conf-low';
  const dotClass   = field.confidence >= 90 ? 'high'      : field.confidence >= 75 ? 'mid'      : 'low';

  if (isSkipped) {
    return (
      <div className="field-card field-card-skipped">
        <div className="field-card-name">{field.label}</div>
        <div className="field-card-value field-card-na">Not available</div>
        <div className="field-card-meta">
          <span className="field-card-skip-tag">
            <i className="ti ti-ban" aria-hidden="true" /> SME skipped
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="field-card">
      <div className="field-card-name">{field.label}</div>
      {isEditing ? (
        <input
          autoFocus
          defaultValue={currentValue}
          onBlur={e => onCommit(field.label, e.target.value)}
          onKeyDown={e => onKeyDown(e, field.label)}
          className="field-card-edit-input"
        />
      ) : (
        <div className="field-card-value-row">
          <span className="field-card-value">{currentValue}</span>
          {isManual  && <span className="field-card-manual-tag">Manually entered</span>}
          {isEdited  && <Badge color="amber">edited</Badge>}
          <button
            className="field-edit-btn"
            onClick={() => onStartEdit(field.label)}
            aria-label={`Edit ${field.label}`}
          >
            <i className="ti ti-pencil" aria-hidden="true" />
          </button>
        </div>
      )}
      <div className="field-card-meta">
        {field.entryMode === 'extracted' && (
          <span className={`${confClass} field-card-conf`}>
            <span className={`conf-dot ${dotClass}`} />
            {field.confidence}%
          </span>
        )}
        {field.source && (
          <button className="view-source-btn" onClick={() => setSourceOpen(s => !s)}>
            <i className={`ti ti-${sourceOpen ? 'chevron-up' : 'link'}`} aria-hidden="true" />
            {sourceOpen ? 'Hide' : 'View Source'}
          </button>
        )}
      </div>
      {sourceOpen && field.source && (
        <div className="source-citation">{field.source}</div>
      )}
    </div>
  );
}
// ─── Screen 4: Compare ───────────────────────────────────────────────────────

// Strip $ / commas → raw numeric string for the number input
function toRaw(val) {
  if (!val || val === '—') return '';
  return String(val).replace(/[$,\s]/g, '');
}
// Raw numeric string → formatted dollar string for display and storage
function toFormatted(raw) {
  const n = parseFloat(raw);
  if (isNaN(n)) return '—';
  return '$' + n.toLocaleString('en-US', { maximumFractionDigits: 0 });
}
function CompareRow({ field, onResolve, onJumpToSlide, nudgeValue = null, onPendingChange = null }) {
  const isSkipped   = field.flag === 'SME skipped — data not available';
  const bestVal     = field.sme ?? field.claude;
  const scriptMatch = !isSkipped && field.script !== '—' && field.script === bestVal;

  // Duplicate-aware: only active when pastValue !== undefined (i.e. a duplicate record exists)
  const pastValue   = field.pastValue; // undefined = no duplicate, null = dup exists but field missing
  const dupMode     = pastValue !== undefined;
  const newValue    = bestVal ?? field.script;
  const isNewField  = dupMode && pastValue === null && newValue != null && newValue !== '—';
  const isChanged   = dupMode && pastValue !== null && newValue != null && newValue !== '—' && toRaw(newValue) !== toRaw(pastValue);
  const isPastOnly  = dupMode && pastValue !== null && (newValue == null || newValue === '—');

  const [editVal,     setEditVal]     = useState(toRaw(bestVal));
  const [confirmed,   setConfirmed]   = useState(true);
  const [expanded,    setExpanded]    = useState(false);
  const [smeApproved, setSmeApproved] = useState(false);

  const prevNudgeRef   = useRef(null);
  const savedEditRef   = useRef('');   // snapshot of editVal when entering edit mode

  useEffect(() => {
    if (nudgeValue !== null && nudgeValue !== prevNudgeRef.current) {
      prevNudgeRef.current = nudgeValue;
      setEditVal(toRaw(nudgeValue));
      setConfirmed(true);
      setSmeApproved(false);
    }
  }, [nudgeValue]);

  const enterEdit = () => { savedEditRef.current = editVal; setConfirmed(false); };
  const cancelEdit = () => { setEditVal(savedEditRef.current); setConfirmed(true); };

  // Report the current confirmed value to ScreenCompare even before the row is
  // approved — so the aggregate check and dup check can react to pending edits.
  useEffect(() => {
    if (onPendingChange) {
      onPendingChange(field.label, confirmed ? toFormatted(editVal) : null);
    }
  }, [confirmed, editVal]);

  const scriptConfMed  = field.scriptConfidence != null && field.scriptConfidence >= 70 && field.scriptConfidence < 90;
  const claudeConfMed  = field.claudeConfidence != null && field.claudeConfidence >= 70 && field.claudeConfidence < 90;
  const interMismatch  = !isSkipped && field.script !== '—' && field.claude != null && field.script !== field.claude;
  const isUncertain    = !isSkipped && (field.scriptUncertain || interMismatch || scriptConfMed || claudeConfMed || field.dupFlag);

  useEffect(() => {
    onResolve(field.label, confirmed && (!isUncertain || smeApproved) ? toFormatted(editVal) : null);
  }, [confirmed, editVal, smeApproved]);

  const rowState = isSkipped ? 'skipped' : isUncertain && !smeApproved ? 'uncertain' : confirmed ? 'match' : 'mismatch';
  const hasSource = field.scriptRaw || field.claudeSource;

  return (
    <div className={`compare-row ${rowState}`}>

      {/* Field name */}
      <span className="compare-cell-field">
        {field.label}
        {isNewField && (
          <span style={{ display:'inline-flex', alignItems:'center', gap:4, marginLeft:8, background:'#fef3c7', color:'#92400e', fontSize:10, fontWeight:700, letterSpacing:'0.06em', textTransform:'uppercase', padding:'2px 7px', borderRadius:20, border:'1px solid #fcd34d' }}>
            <i className="ti ti-sparkles" style={{ fontSize:11 }} /> New information
          </span>
        )}
        {isChanged && (
          <span style={{ display:'inline-flex', alignItems:'center', gap:4, marginLeft:8, background:'#fef3c7', color:'#92400e', fontSize:10, fontWeight:700, letterSpacing:'0.06em', textTransform:'uppercase', padding:'2px 7px', borderRadius:20, border:'1px solid #fcd34d' }}>
            <i className="ti ti-refresh" style={{ fontSize:11 }} /> Updated
          </span>
        )}
        {hasSource && (
          <button
            className={`compare-source-toggle ${expanded ? 'is-open' : ''}`}
            onClick={() => setExpanded(e => !e)}
            aria-label={expanded ? 'Hide extraction source' : 'View extraction source'}
          >
            <i className="ti ti-file-search" aria-hidden="true" />
            <span>{expanded ? 'Hide source' : 'View source'}</span>
            <i className={`ti ti-chevron-${expanded ? 'up' : 'down'}`} aria-hidden="true" />
          </button>
        )}
      </span>

      {/* Script value — always shown when the script found one, independent of
          the SME-skipped flag (skipping concerns the Claude/SME side, not the
          deterministic script extractor). */}
      {(!field.script || field.script === '—') ? (
        <span className="compare-na">—</span>
      ) : (
        <span className={`compare-script ${(!isSkipped && !scriptMatch) ? 'is-mismatch' : ''}`}>
          <span
            className="compare-conf-wrap"
            data-tip={field.scriptConfidence != null ? `${field.scriptConfidence}% — ${field.scriptConfidence >= 90 ? 'High confidence' : field.scriptConfidence >= 70 ? 'Medium confidence' : 'Low confidence'}` : undefined}
          >
            {field.scriptConfidence != null && (
              <span className={`compare-conf-dot ${field.scriptConfidence >= 90 ? 'high' : field.scriptConfidence >= 70 ? 'med' : 'low'}`} />
            )}
            {field.script}
          </span>
          {field.scriptUncertain && field.scriptAlternates.length > 0 && (
            <span className="compare-alt">
              also: {field.scriptAlternates.map(a => a.value).filter(Boolean).join(', ')}
            </span>
          )}
        </span>
      )}

      {/* Claude AI value */}
      {field.claude ? (
        <span
          className="compare-mono compare-conf-wrap"
          data-tip={field.claudeConfidence != null ? `${field.claudeConfidence}% — ${field.claudeConfidence >= 90 ? 'High' : field.claudeConfidence >= 70 ? 'Med' : 'Low'}` : undefined}
        >
          {field.claudeConfidence != null && (
            <span className={`compare-conf-dot ${field.claudeConfidence >= 90 ? 'high' : field.claudeConfidence >= 70 ? 'med' : 'low'}`} />
          )}
          {field.claude}
        </span>
      ) : (
        <span className="compare-na">—</span>
      )}

      {/* Final Value — confirmed: value + pencil; editing: input + Done */}
      <div className="compare-final">
        {isSkipped ? (
          <span className="compare-na">—</span>
        ) : confirmed ? (
          <div className="compare-final-confirmed">
            <span
              className="compare-final-value compare-final-value--clickable"
              onClick={enterEdit}
              title="Click to edit"
              role="button"
              tabIndex={0}
              onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') enterEdit(); }}
            >
              {toFormatted(editVal)}
            </span>
            <button
              onClick={enterEdit}
              title="Edit final value"
              className="compare-edit-btn"
              aria-label="Edit final value"
            >
              <i className="ti ti-pencil" aria-hidden="true" />
            </button>
            {isUncertain && !smeApproved && (
              <button
                onClick={() => setSmeApproved(true)}
                title="Mark as reviewed by SME"
                className="compare-approve-btn"
              >
                <i className="ti ti-check" aria-hidden="true" /> Approve
              </button>
            )}
            {smeApproved && (
              <span className="compare-approved-badge">
                <i className="ti ti-circle-check" aria-hidden="true" /> Reviewed
              </span>
            )}
          </div>
        ) : (
          <div className="compare-final-editing">
            <div className="input-prefix-group compare-final-input">
              <span className="input-prefix">$</span>
              <input
                autoFocus
                type="number"
                min="0"
                step="any"
                value={editVal}
                onChange={e => setEditVal(e.target.value)}
                placeholder="0"
              />
            </div>
            <button
              className="compare-done-btn"
              onClick={() => setConfirmed(true)}
            >
              Done
            </button>
            <button
              className="compare-cancel-btn"
              onClick={cancelEdit}
              title="Cancel edit"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      {/* Source panel — spans all columns, visible when expanded */}
      {expanded && hasSource && (
        <div className="compare-source-panel">
          {field.scriptRaw && (
            <div className="compare-source-item">
              <span className="compare-source-tag script">Script</span>
              {field.scriptSlide && (
                onJumpToSlide
                  ? <button className="compare-source-slide compare-source-slide--btn" onClick={() => onJumpToSlide(field.scriptSlide - 1)}>
                      <i className="ti ti-presentation" /> Slide {field.scriptSlide}
                    </button>
                  : <span className="compare-source-slide">Slide {field.scriptSlide}</span>
              )}
              <span className="compare-source-text">"{field.scriptRaw}"</span>
            </div>
          )}
          {field.claudeSource && (
            <div className="compare-source-item">
              <span className="compare-source-tag claude">Claude AI</span>
              {(() => {
                const slideNum = field.claudeSlide ?? (() => {
                  const m = String(field.claudeSource).match(/^Slide\s+(\d+)/i);
                  return m ? parseInt(m[1], 10) : null;
                })();
                return slideNum && onJumpToSlide
                  ? <button className="compare-source-slide compare-source-slide--btn" onClick={() => onJumpToSlide(slideNum - 1)}>
                      <i className="ti ti-presentation" /> Slide {slideNum}
                    </button>
                  : slideNum
                  ? <span className="compare-source-slide">Slide {slideNum}</span>
                  : null;
              })()}
              <span className="compare-source-text">"{field.claudeSource}"</span>
            </div>
          )}
        </div>
      )}

      {/* Duplicate value notice — shown until SME approves */}
      {field.dupFlag && !smeApproved && (
        <div className="compare-dup-notice">
          <i className="ti ti-alert-triangle" aria-hidden="true" />
          This field has the same value as a related field. This is very unlikely — please verify both before approving.
        </div>
      )}

      {/* Past information row — shown when a duplicate record exists */}
      {(pastValue || isPastOnly) && (
        <div style={{ gridColumn:'1 / -1', display:'flex', alignItems:'center', gap:10, padding:'8px 14px', marginTop:4, background:'#f8fafc', border:'1px solid #e2e8f0', borderRadius:8, opacity:0.75 }}>
          <span style={{ fontSize:11, fontWeight:700, letterSpacing:'0.07em', textTransform:'uppercase', color:'#94a3b8', flexShrink:0 }}>Past information</span>
          <span style={{ fontSize:13, color:'#64748b', fontFamily:'monospace', fontWeight:600 }}>{pastValue}</span>
          {(isChanged || isPastOnly) && (
            <span style={{ fontSize:11, color:'#94a3b8', fontStyle:'italic' }}>
              {isChanged ? 'Value updated in new document' : 'Not found in new document'}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
function ScreenCompare({ fields, scriptData, scriptMeta = null, batchInfo = null, onExclude = null, onNext, onBack, smeName = '', fileMeta = null, duplicateRecord = null }) {
  const [slideOpen, setSlideOpen] = useState(false);
  const slideStackRef = useRef(null);
  const isMulti = batchInfo?.total > 1;

  // scriptMeta (from ROAR) takes priority — it reflects what's actually in the document.
  // fileMeta is the fallback from the user-entered form values.
  const _initMeta = useMemo(() => {
    const client_scope_name = String(scriptMeta?.client_scope_name || fileMeta?.client_scope_name || fileMeta?.upClient || '');
    return {
      publisher:        String(scriptMeta?.publisher || fileMeta?.publisher || fileMeta?.upPublisher || ''),
      currency:         String(scriptMeta?.currency || fileMeta?.currency || 'USD'),
      date_delivered:   String(scriptMeta?.date_delivered || fileMeta?.date_delivered || new Date().toISOString().split('T')[0]),
      client_scope_name: client_scope_name,
      applicable_from:  String(scriptMeta?.applicable_from || fileMeta?.applicable_from || ''),
      applicable_to:    String(scriptMeta?.applicable_to || fileMeta?.applicable_to || ''),
    };
  }, [scriptMeta, fileMeta]);
  const [metaDetails, setMetaDetails] = useState(_initMeta);

  // Safety net: re-sync if scriptMeta arrived after first render (async extraction).
  useEffect(() => {
    setMetaDetails(prev => {
      const next = _initMeta;
      return {
        publisher:        prev.publisher || next.publisher,
        currency:         prev.currency  || next.currency,
        date_delivered:   prev.date_delivered || next.date_delivered,
        client_scope_name: prev.client_scope_name || next.client_scope_name,
        applicable_from:  prev.applicable_from || next.applicable_from,
        applicable_to:    prev.applicable_to || next.applicable_to,
      };
    });
  }, [scriptMeta]);
  const [clientRecords, setClientRecords] = useState(null);
  const [suggestedOverrides, setSuggestedOverrides] = useState({});
  // pendingValues: confirmed-but-possibly-not-yet-approved edits from CompareRow.
  // Used by the aggregate check and dup check so they react even when a yellow row
  // hasn't been approved yet (resolved[label] stays null until approval).
  const [pendingValues, setPendingValues] = useState({});

  // Per-field date overrides — only populated when a field's window differs from the record default.
  const [fieldDates, setFieldDates] = useState(() => {
    const hubCtx = getHubContext();
    const startDates = hubCtx?.start_dates || [];
    const endDates = hubCtx?.end_dates || [];
    const entries = [...MONETARY_LABELS].map((label, idx) => [
      label, 
      { 
        from: startDates[idx] || '', 
        to: endDates[idx] || '' 
      }
    ]);
    return Object.fromEntries(entries);
  });
  const setFieldDate = (label, key, val) =>
    setFieldDates(prev => ({ ...prev, [label]: { ...prev[label], [key]: val } }));
  const [overridesOpen, setOverridesOpen] = useState(false);

  const handlePendingChange = (label, val) => {
    setPendingValues(prev => ({ ...prev, [label]: val }));
  };

  useEffect(() => {
    const client = fileMeta?.client || fileMeta?.upClient;
    getRecords()
      .then(recs => {
        setClientRecords(client ? (recs || []).filter(r => r.client === client) : []);
      })
      .catch(() => setClientRecords([]));
  }, []);
  // Build rows from live extracted fields + the script extractor's values.
  // script = deterministic .pptx extractor — real values only (null when no file was
  //          uploaded, e.g. the SharePoint search path, where the Script column shows —).
  // claude = what the AI extracted (null if it couldn't find it).
  // sme    = what the SME computed via the fallback form (null if extracted or skipped).
  const hasRealScript = scriptData && Object.keys(scriptData).length > 0;
  const scriptFor = (label) => {
    if (hasRealScript) return scriptData[label] || null;   // {value, uncertain, alternates} | null
    return null;
  };

  // Map label → flat API key on the existing duplicate record
  const PAST_FIELD_KEY = {
    'Identified Risk':                'identified_risk',
    'Identified Cost Avoidance':      'id_cost_avoidance',
    'Accomplished Cost Avoidance':    'acc_cost_avoidance',
    'Identified Cost Optimization':   'id_cost_optimization',
    'Accomplished Cost Optimization': 'acc_cost_optimization',
    'Identified Cost Savings':        'id_cost_savings',
    'Realized Cost Savings':          'realized_savings',
  };
  const fmtPast = (n) => {
    const num = Number(n);
    if (!num) return null;
    return `$${num.toLocaleString()}`;
  };
  const pastFor = (label) => {
    if (!duplicateRecord) return undefined; // no duplicate context — don't show any tags
    const key = PAST_FIELD_KEY[label];
    return key ? fmtPast(duplicateRecord[key]) : null; // null = field not in past record
  };

  const sourceFields = fields && fields.length > 0 ? fields : [];
  const compareRows = sourceFields.map(f => {
    const s = scriptFor(f.label);
    return {
      label:  f.label,
      script: s?.value ?? '—',
      scriptUncertain:  s?.uncertain ?? false,
      scriptAlternates: s?.alternates ?? [],
      scriptConfidence: s?.confidence ?? null,
      scriptRaw:        s?.raw ?? null,
      scriptSlide:      s?.sourceSlide ?? null,
      claude: f.entryMode === 'extracted' ? f.value : null,
      claudeConfidence: f.confidence ?? null,
      claudeSource:     f.source ?? null,
      claudeSlide:      f.source_slide ?? null,
      sme:    f.entryMode === 'manual'    ? f.value : null,
      flag:   f.flag,
      pastValue: pastFor(f.label),
    };
  });

  // dupFlag phase 1: check initial extracted values (no state needed yet)
  const _rowBest = (label) => {
    const r = compareRows.find(x => x.label === label);
    return r ? (r.sme ?? r.claude) : null;
  };
  const _accOptBest  = _rowBest('Accomplished Cost Optimization');
  const _realSavBest = _rowBest('Realized Cost Savings');
  const _hasDupFlag  = Boolean(
    _accOptBest && _realSavBest &&
    _accOptBest !== '—' && _realSavBest !== '—' &&
    parseDollar(_accOptBest) > 0 && parseDollar(_realSavBest) > 0 &&
    _accOptBest === _realSavBest
  );

  const [resolved, setResolved] = useState({});

  const handleResolve = (label, val) => {
    setResolved(prev => ({ ...prev, [label]: val }));
  };

  // dupFlag phase 2: also flag when the user's resolved/pending values become equal
  // (now safe to reference resolved and pendingValues, both declared above)
  const _resolvedAccOpt  = resolved['Accomplished Cost Optimization']  ?? pendingValues['Accomplished Cost Optimization'];
  const _resolvedRealSav = resolved['Realized Cost Savings']           ?? pendingValues['Realized Cost Savings'];
  const _resolvedDupActive = Boolean(
    _resolvedAccOpt && _resolvedRealSav &&
    parseDollar(_resolvedAccOpt) > 0 && parseDollar(_resolvedRealSav) > 0 &&
    _resolvedAccOpt === _resolvedRealSav
  );
  const _anyDupFlag = _hasDupFlag || _resolvedDupActive;
  const finalCompareRows = _anyDupFlag
    ? compareRows.map(r =>
        r.label === 'Accomplished Cost Optimization' || r.label === 'Realized Cost Savings'
          ? { ...r, dupFlag: true }
          : r
      )
    : compareRows;

  // Skipped rows don't need SME resolution — only non-skipped rows must be confirmed
  const resolvableRows = finalCompareRows.filter(f => f.flag !== 'SME skipped — data not available');
  const allDone = resolvableRows.every(f => resolved[f.label] !== null && resolved[f.label] !== undefined);

  // "Best available" value per row — prefer sme-computed, fall back to claude extracted
  const bestVal = (row) => row.sme ?? row.claude;

  // A row is "ok" only when both extractors agree on a high-confidence value
  const isInterMismatch = (r) => r.script !== '—' && r.claude != null && r.script !== r.claude;
  const confOk = (r) =>
    !r.scriptUncertain &&
    !isInterMismatch(r) &&
    (r.scriptConfidence == null || r.scriptConfidence >= 90) &&
    (r.claudeConfidence == null || r.claudeConfidence >= 90);

  // Group fields needing review by issue type
  const isCompeting = (r) => r.scriptUncertain || isInterMismatch(r);
  const isLowConf   = (r) => (r.scriptConfidence != null && r.scriptConfidence < 70) || (r.claudeConfidence != null && r.claudeConfidence < 70);
  const isMedConf   = (r) => (r.scriptConfidence != null && r.scriptConfidence >= 70 && r.scriptConfidence < 90) || (r.claudeConfidence != null && r.claudeConfidence >= 70 && r.claudeConfidence < 90);

  // Yellow rows = any of the uncertain conditions (mirrors CompareRow rowState logic)
  const isYellow    = (r) => isCompeting(r) || isLowConf(r) || isMedConf(r) || r.dupFlag;
  const reviewCount = resolvableRows.filter(isYellow).length;
  const matchCount  = resolvableRows.length - reviewCount;
  const lowestConf  = (r) => { const vs = [r.scriptConfidence, r.claudeConfidence].filter(v => v != null); return vs.length ? Math.round(Math.min(...vs)) : null; };

  const reviewGroups = [
    { key: 'competing', label: 'Competing values',   items: resolvableRows.filter(isCompeting).map(r => r.label) },
    { key: 'lowconf',   label: 'Low confidence',     items: resolvableRows.filter(r => !isCompeting(r) && isLowConf(r)).map(r => { const p = lowestConf(r); return p != null ? `${r.label} (${p}%)` : r.label; }) },
    { key: 'medconf',   label: 'Medium confidence',  items: resolvableRows.filter(r => !isCompeting(r) && !isLowConf(r) && isMedConf(r)).map(r => { const p = lowestConf(r); return p != null ? `${r.label} (${p}%)` : r.label; }) },
    { key: 'dupflag',   label: 'Duplicate value — verify', items: resolvableRows.filter(r => r.dupFlag).map(r => r.label) },
  ].filter(g => g.items.length > 0);

  const handleNext = () => {
    const resolvedFields = sourceFields.map(f => {
      const finalVal = resolved[f.label];
      if (finalVal && finalVal !== f.value) {
        return { ...f, value: finalVal };
      }
      return f;
    });
    onNext(resolvedFields, { ...metaDetails, fieldDates });
  };

  // Aggregate consistency check: accomplished ≤ identified across all client history + current
  // Uses the user's resolved value when available, falls back to the initial extraction value.
  const aggWarnings = useMemo(() => {
    if (!clientRecords) return [];
    const warnings = [];
    const getNum = (label) => {
      const r = finalCompareRows.find(x => x.label === label);
      // resolved is set only when confirmed+approved; pendingValues when confirmed but not yet approved
      const v = resolved[label] ?? pendingValues[label] ?? (r ? (r.sme ?? r.claude) : null);
      const n = parseDollar(v);
      return isNaN(n) ? 0 : n;
    };
    const sum = (field) => clientRecords.reduce((acc, r) => acc + (r[field] || 0), 0);

    const histAccAvd = sum('acc_cost_avoidance');
    const histIdAvd  = sum('id_cost_avoidance');
    const currAccAvd = getNum('Accomplished Cost Avoidance');
    const currIdAvd  = getNum('Identified Cost Avoidance');
    if ((histAccAvd + currAccAvd) > (histIdAvd + currIdAvd) && (histAccAvd + currAccAvd) > 0) {
      const gap = (histAccAvd + currAccAvd) - (histIdAvd + currIdAvd);
      warnings.push({
        label:     'Identified Cost Avoidance',
        pair:      'cost avoidance',
        gap,
        suggested: currIdAvd + gap,
      });
    }

    const histAccOpt = sum('acc_cost_optimization');
    const histIdOpt  = sum('id_cost_optimization');
    const currAccOpt = getNum('Accomplished Cost Optimization');
    const currIdOpt  = getNum('Identified Cost Optimization');
    if ((histAccOpt + currAccOpt) > (histIdOpt + currIdOpt) && (histAccOpt + currAccOpt) > 0) {
      const gap = (histAccOpt + currAccOpt) - (histIdOpt + currIdOpt);
      warnings.push({
        label:     'Identified Cost Optimization',
        pair:      'cost optimization',
        gap,
        suggested: currIdOpt + gap,
      });
    }

    return warnings;
  }, [clientRecords, finalCompareRows, resolved, pendingValues]);

  // Reactive dup-value check: warns if the user edits resolved values into equality.
  // Suppressed if the original extracted values were ALREADY equal (_hasDupFlag) —
  // the row-level warning + approval flow covers that case.
  const resolvedDupWarning = useMemo(() => {
    if (_anyDupFlag) return false; // rows are already highlighted — no need for a separate banner
    const v1 = resolved['Accomplished Cost Optimization'] ?? pendingValues['Accomplished Cost Optimization'];
    const v2 = resolved['Realized Cost Savings']          ?? pendingValues['Realized Cost Savings'];
    if (!v1 || !v2) return false;
    const n1 = parseDollar(v1);
    const n2 = parseDollar(v2);
    return !isNaN(n1) && !isNaN(n2) && n1 > 0 && n2 > 0 && v1 === v2;
  }, [resolved, pendingValues, _anyDupFlag]);

  const storedName = fileMeta?.stored_name || null;

  return (
    <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>

      {/* ── Review card ── */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="card compare-card">

      {/* Header */}
      <div className="compare-head">
        {isMulti && (
          <div className="batch-progress">
            <i className="ti ti-files" aria-hidden="true" />
            File {batchInfo.index + 1} of {batchInfo.total}{batchInfo.name ? ` — ${batchInfo.name}` : ''}
          </div>
        )}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          <div className="card-title compare-title">
            <i className="ti ti-git-compare" aria-hidden="true" />
            Script vs. Claude AI — Field Comparison
          </div>
          {storedName && (
            <button
              onClick={() => setSlideOpen(o => !o)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '6px 14px', borderRadius: 8, cursor: 'pointer',
                fontFamily: 'inherit', fontSize: 12, fontWeight: 700,
                background: slideOpen ? 'var(--surface-2)' : 'var(--navy)',
                color: slideOpen ? 'var(--text)' : '#fff',
                border: slideOpen ? '1.5px solid var(--border)' : 'none',
                flexShrink: 0,
              }}
            >
              <i className={`ti ${slideOpen ? 'ti-layout-sidebar-left-collapse' : 'ti-presentation'}`} />
              {slideOpen ? 'Hide slides' : 'View slides'}
            </button>
          )}
        </div>
        <div className="compare-summary">
          <span className="compare-match">
            <i className="ti ti-circle-check" aria-hidden="true" />
            {matchCount} match{matchCount !== 1 ? 'es' : ''}
          </span>
          <span className="compare-mismatch-label">
            <i className="ti ti-alert-triangle" aria-hidden="true" />
            {reviewCount} need{reviewCount === 1 ? 's' : ''} review
          </span>
        </div>

        {reviewGroups.length > 0 && (
          <div className="compare-uncertain">
            <div className="compare-uncertain-header">
              <i className="ti ti-alert-triangle compare-uncertain-icon" aria-hidden="true" />
              <strong>Review required before saving</strong>
            </div>
            <ul className="compare-uncertain-list">
              {reviewGroups.map(g => (
                <li key={g.key}><strong>{g.label}:</strong> {g.items.join(' · ')}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Column headers */}
      <div className="compare-header">
        <span>Field</span>
        <span>Script</span>
        <span>Claude AI</span>
        <span>Final Value</span>
      </div>

      {/* Rows */}
      <div>
        {finalCompareRows.map(f => (
          <CompareRow
            key={f.label}
            field={f}
            onResolve={handleResolve}
            onPendingChange={handlePendingChange}
            onJumpToSlide={storedName ? (idx) => { setSlideOpen(true); setTimeout(() => slideStackRef.current?.jumpTo(idx), 80); } : null}
            nudgeValue={suggestedOverrides[f.label] ?? null}
          />
        ))}
      </div>

      {/* Aggregate consistency warnings + reactive dup-value warning */}
      {(aggWarnings.length > 0 || resolvedDupWarning) && (
        <div className="compare-agg-warnings">
          {resolvedDupWarning && (
            <div className="compare-agg-warning">
              <div className="compare-agg-warning-body">
                <i className="ti ti-alert-triangle" aria-hidden="true" />
                <span>
                  <strong>Duplicate value detected:</strong> Accomplished Cost Optimization and Realized Cost Savings
                  have been set to the same value. This is very unlikely — please verify both fields.
                </span>
              </div>
            </div>
          )}
          {aggWarnings.map(w => (
            <div key={w.label} className="compare-agg-warning">
              <div className="compare-agg-warning-body">
                <i className="ti ti-chart-bar" aria-hidden="true" />
                <span>
                  <strong>Aggregate check:</strong> Across all {fileMeta?.client_scope_name || fileMeta?.upClient || 'this client'}'s records,
                  accomplished {w.pair} would exceed identified {w.pair} by{' '}
                  <strong>{formatDollar(w.gap)}</strong> after this extraction.
                  Suggested minimum for <em>{w.label}</em>:{' '}
                  <strong>{formatDollar(w.suggested)}</strong>.
                </span>
              </div>
              <button
                className="btn ghost compare-agg-apply-btn"
                onClick={() => setSuggestedOverrides(prev => ({ ...prev, [w.label]: formatDollar(w.suggested) }))}
              >
                Apply suggested value
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Record Details — non-ROI metadata fields for review before save */}
      <div className="compare-record-details">
        <div className="compare-record-details-header">
          <i className="ti ti-info-circle" aria-hidden="true" />
          Record Details
        </div>
        <div className="compare-record-details-grid">
          {[
            { key: 'publisher',      label: 'Publisher',      type: 'text',   placeholder: 'e.g. Microsoft' },
            { key: 'currency',       label: 'Currency',       type: 'text',   placeholder: 'USD' },
            { key: 'date_delivered', label: 'Date Extracted', type: 'text',   placeholder: 'e.g. 2024-03-15' },
          ].map(({ key, label, type, placeholder }) => (
            <div key={key} className="compare-record-detail-item">
              <label className="compare-record-detail-label">{label}</label>
              {key === 'publisher' ? (
                <PublisherField
                  value={metaDetails[key]}
                  onChange={v => setMetaDetails(prev => ({ ...prev, publisher: v }))}
                  placeholder={placeholder}
                />
              ) : (
                <input
                  type={type}
                  className="compare-record-detail-input"
                  value={metaDetails[key]}
                  onChange={e => setMetaDetails(prev => ({ ...prev, [key]: e.target.value }))}
                  placeholder={placeholder}
                />
              )}
            </div>
          ))}
        </div>

        {/* Applicability date range */}
        <div style={{ marginTop: 12, padding: '10px 12px', background: 'rgba(0,95,134,0.06)', borderRadius: 6, border: '1px solid rgba(0,95,134,0.14)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
            <i className="ti ti-calendar-stats" style={{ fontSize: 13, color: '#005f86' }} aria-hidden="true" />
            <span style={{ fontWeight: 600, fontSize: 12, color: '#005f86' }}>Value applicability period</span>
          </div>
          <p style={{ margin: '0 0 8px', fontSize: 11.5, color: '#475569', lineHeight: 1.5 }}>
            The date range during which this engagement's ROI values are considered active.
            This is used for time-based reporting — for example, to show only savings that were
            in effect during a given quarter. Defaults to the full delivery year.
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <label style={{ fontSize: 11, color: '#64748b', fontWeight: 500 }}>From</label>
              <input
                type="date"
                className="compare-record-detail-input"
                value={metaDetails.applicable_from || ''}
                onChange={e => setMetaDetails(prev => ({ ...prev, applicable_from: e.target.value }))}
                style={{ fontSize: 12, padding: '3px 7px' }}
              />
            </div>
            <span style={{ color: '#94a3b8', fontSize: 13 }}>→</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <label style={{ fontSize: 11, color: '#64748b', fontWeight: 500 }}>To</label>
              <input
                type="date"
                className="compare-record-detail-input"
                value={metaDetails.applicable_to || ''}
                onChange={e => setMetaDetails(prev => ({ ...prev, applicable_to: e.target.value }))}
                style={{ fontSize: 12, padding: '3px 7px' }}
              />
            </div>
          </div>
        </div>

        {/* Per-field overrides — collapsed by default */}
        <div style={{ marginTop: 8 }}>
          <button
            onClick={() => setOverridesOpen(o => !o)}
            style={{
              display: 'flex', alignItems: 'center', gap: 5, width: '100%',
              background: 'none', border: 'none', padding: '6px 2px',
              fontSize: 11.5, color: '#64748b', cursor: 'pointer', fontFamily: 'inherit',
            }}
          >
            <i className={`ti ti-chevron-${overridesOpen ? 'down' : 'right'}`} style={{ fontSize: 11 }} aria-hidden="true" />
            <span style={{ fontWeight: 500 }}>Override dates for individual values</span>
            <span style={{ marginLeft: 4, opacity: 0.65 }}>(optional — only if a specific value has a different window)</span>
          </button>
          {overridesOpen && (
            <div style={{ marginTop: 4, padding: '8px 10px', background: '#f8fafc', borderRadius: 6, border: '1px solid #e2e8f0' }}>
              <p style={{ margin: '0 0 10px', fontSize: 11, color: '#64748b', lineHeight: 1.45 }}>
                All values inherit the period above by default. Use these only when a specific
                value was active for a meaningfully different window — for example, if identified
                risk applied January through June but realized savings continued through December.
              </p>
              {[...MONETARY_LABELS].map(label => (
                <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 11.5, color: '#334155', fontWeight: 500, minWidth: 210 }}>{label}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <label style={{ fontSize: 11, color: '#94a3b8' }}>From</label>
                    <input
                      type="date"
                      value={fieldDates[label]?.from || ''}
                      onChange={e => setFieldDate(label, 'from', e.target.value)}
                      placeholder={metaDetails.applicable_from || ''}
                      style={{ fontSize: 11, padding: '2px 6px', borderRadius: 4, border: '1px solid #cbd5e1', color: '#334155', background: '#fff', fontFamily: 'inherit' }}
                    />
                  </div>
                  <span style={{ color: '#cbd5e1', fontSize: 12 }}>→</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <label style={{ fontSize: 11, color: '#94a3b8' }}>To</label>
                    <input
                      type="date"
                      value={fieldDates[label]?.to || ''}
                      onChange={e => setFieldDate(label, 'to', e.target.value)}
                      placeholder={metaDetails.applicable_to || ''}
                      style={{ fontSize: 11, padding: '2px 6px', borderRadius: 4, border: '1px solid #cbd5e1', color: '#334155', background: '#fff', fontFamily: 'inherit' }}
                    />
                  </div>
                  {(fieldDates[label]?.from || fieldDates[label]?.to) && (
                    <button
                      onClick={() => { setFieldDate(label, 'from', ''); setFieldDate(label, 'to', ''); }}
                      style={{ fontSize: 10, color: '#94a3b8', background: 'none', border: 'none', cursor: 'pointer', padding: '0 2px' }}
                      title="Clear override — revert to record default"
                    >clear</button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* What gets stored */}
      <div className="compare-stored">
        <div className="compare-stored-header">
          <div className="compare-stored-title">
            <i className="ti ti-database" aria-hidden="true" />
            WHAT GETS STORED
          </div>
          <span className="compare-stored-subtitle">Saved automatically when you click Save &amp; Done</span>
        </div>
        <div className="compare-stored-items">
          <div className="compare-stored-item">
            <div className="compare-stored-icon-wrap file">
              <i className="ti ti-file-text" aria-hidden="true" />
            </div>
            <div>
              <span className="compare-stored-label">Source file</span>
              <span className="compare-stored-value">{fileMeta?.name || batchInfo?.name || '—'}</span>
            </div>
          </div>
          <div className="compare-stored-item">
            <div className="compare-stored-icon-wrap sme">
              <i className="ti ti-user-check" aria-hidden="true" />
            </div>
            <div>
              <span className="compare-stored-label">SME checkpoint</span>
              <span className="compare-stored-value">{smeName || '—'}</span>
            </div>
          </div>
          <div className="compare-stored-item">
            <div className="compare-stored-icon-wrap audit">
              <i className="ti ti-clipboard-list" aria-hidden="true" />
            </div>
            <div>
              <span className="compare-stored-label">Audit record</span>
              <span className="compare-stored-value">Auto-created on save</span>
            </div>
          </div>
        </div>
        <div className="compare-stored-roi-section">
          <span className="compare-stored-label">ROI values</span>
          <div className="compare-stored-roi-chips">
            {resolvableRows.map(row => {
              const confirmedVal = resolved[row.label];
              const tentativeVal = pendingValues[row.label];
              const displayVal   = confirmedVal ?? tentativeVal;
              const hasValue     = displayVal && displayVal !== '—';
              const isApproved   = confirmedVal != null && hasValue;
              const needsApproval = !isApproved && hasValue;
              const chipClass    = isApproved ? 'confirmed' : needsApproval ? 'needs-approval' : 'pending';
              return (
                <span key={row.label} className={`compare-stored-chip ${chipClass}`}>
                  <i className={`ti ${isApproved ? 'ti-circle-check' : 'ti-circle-dashed'}`} aria-hidden="true" />
                  {row.label}{displayVal && displayVal !== '—' && <strong>{displayVal}</strong>}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="compare-footer">
        <div className="compare-footer-left">
          <button className="btn ghost" onClick={onBack}>
            <i className="ti ti-arrow-left" aria-hidden="true" /> Back
          </button>
          {isMulti && onExclude && (
            <button className="btn ghost compare-exclude-btn" onClick={onExclude}>
              <i className="ti ti-file-off" aria-hidden="true" /> Exclude this file
            </button>
          )}
        </div>
        <div className="compare-footer-actions">
          {!allDone && (
            <span className="compare-resolve-hint">
              Approve yellow rows to continue
            </span>
          )}
          <button
            className="btn primary is-gated"
            disabled={!allDone}
            onClick={handleNext}
          >
            {isMulti && !batchInfo.isLast
              ? <>Confirm &amp; Next File <i className="ti ti-arrow-right" aria-hidden="true" /></>
              : <>Save &amp; Done <i className="ti ti-arrow-right" aria-hidden="true" /></>
            }
          </button>
        </div>
      </div>{/* end compare-footer */}
        </div>{/* end compare-card */}
      </div>{/* end review card wrapper */}

      {/* ── Slide panel: right side ── */}
      {storedName && slideOpen && (
        <div style={{
          width: 680, flexShrink: 0,
          background: 'var(--surface)',
          border: '1.5px solid var(--border)',
          borderRadius: 14,
          overflow: 'hidden',
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
          position: 'sticky', top: 20,
          alignSelf: 'flex-start',
          maxHeight: 'calc(100vh - 40px)',
          display: 'flex', flexDirection: 'column',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '12px 16px',
            borderBottom: '1px solid var(--border)',
          }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--navy)', display: 'flex', alignItems: 'center', gap: 7 }}>
              <i className="ti ti-presentation" /> Document Slides
            </span>
            <button
              onClick={() => setSlideOpen(false)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: 18, lineHeight: 1 }}
            >
              <i className="ti ti-x" />
            </button>
          </div>
          <div style={{ padding: 12, overflowY: 'auto', flex: 1 }} id="slide-scroll-container">
            <SlideStack ref={slideStackRef} storedName={storedName} />
          </div>
        </div>
      )}

    </div>
  );
}
// ─── Screen 4 (host): per-file review ─────────────────────────────────────────
// For the current file: first let the SME fill/skip any missing fields (the
// ScreenExtract review), then resolve the Script-vs-Claude comparison. Remounted
// per file by the parent (keyed on the file index) so each file starts clean.
function FileReview({ fileResult, fileIndex, total, isLast, onConfirm, onExclude, onBack, allStatuses = [], files = [], smeName = '', duplicateRecord = null }) {
  const currentStatus = allStatuses[fileIndex] ?? 'pending';

  if (currentStatus !== 'done') {
    return (
      <div className="card">
        <div className="card-title">
          <i className="ti ti-cpu" aria-hidden="true" /> ROI Extraction
        </div>
        <p className="extract-sub">
          Running the script extractor and Claude AI across {files.length} file{files.length !== 1 ? 's' : ''}…
        </p>
        <div className="extract-steps">
          {files.map((f, i) => {
            const status = allStatuses[i] || 'pending';
            return (
              <div className={`extract-step ${status}`} key={i}>
                <div className="extract-step-icon">
                  {status === 'done'    && <i className="ti ti-check" aria-hidden="true" />}
                  {status === 'running' && <i className="ti ti-loader-2 spinning" aria-hidden="true" />}
                  {status === 'pending' && <i className="ti ti-circle" aria-hidden="true" />}
                </div>
                <span className="extract-step-label">{f.name || `File ${i + 1}`}</span>
                {status === 'done'    && <Badge color="green"><i className="ti ti-check" /> Done</Badge>}
                {status === 'running' && <Badge color="blue">Running…</Badge>}
                {status === 'pending' && <Badge color="navy">Pending</Badge>}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  const batchInfo = { index: fileIndex, total, isLast, name: fileResult.fileMeta?.name };
  const fields = buildClaudeFields(fileResult.extractedData);

  return (
    <ScreenCompare
      fields={fields}
      scriptData={fileResult.scriptData}
      scriptMeta={fileResult.scriptMeta}
      batchInfo={batchInfo}
      onExclude={total > 1 ? onExclude : null}
      onNext={onConfirm}
      onBack={onBack}
      smeName={smeName}
      fileMeta={fileResult.fileMeta}
      duplicateRecord={duplicateRecord}
    />
  );
}

// For a single-file batch this is the original review-and-store screen. For a
// multi-file batch it adds the per-file breakdown, the combined annual aggregate
// (the editable cards), an aggregate-record toggle, and a mixed-batch warning.
function ScreenStore({ fileResults = [], aggregateFields, commonMeta = {}, storeAggregate, onToggleAggregate, smeName, multi = false, onNext, onBack }) {
  // Defensive default for reaching Store directly (e.g. jumping via the Journey Bar)
  // without any extracted fields — show the honest blank-field template, not mock numbers.
  const sourceFields = aggregateFields && aggregateFields.length > 0 ? aggregateFields : BLANK_FIELDS;
  const active = fileResults.filter(r => !r.excluded && r.finalFields);

  const [editValues, setEditValues] = useState(
    () => Object.fromEntries(sourceFields.map(f => [f.label, f.value]))
  );
  const [editingLabel, setEditingLabel] = useState(null);
  const [showFiles, setShowFiles] = useState(true);

  const commitEdit = (label, val) => {
    setEditValues(prev => ({ ...prev, [label]: val }));
    setEditingLabel(null);
  };

  const handleKeyDown = (e, label) => {
    if (e.key === 'Enter')  commitEdit(label, e.target.value);
    if (e.key === 'Escape') setEditingLabel(null);
  };

  const handleSave = () => {
    onNext(sourceFields.map(f => ({ ...f, value: editValues[f.label] })));
  };

  const manualCount = sourceFields.filter(f => f.entryMode === 'manual').length;
  const skippedCount = sourceFields.filter(f => f.flag === 'SME skipped — data not available').length;
  const mixed = commonMeta.mixedPublisher;
  const recordCount = active.length + (multi && storeAggregate ? 1 : 0);

  return (
    <div className="card">
      <div className="card-title">
        <i className="ti ti-database" aria-hidden="true" />
        Review
      </div>
      <p className="store-sub">
        {multi
          ? <>Combined annual total from <strong>{active.length}</strong> file{active.length !== 1 ? 's' : ''}. <strong>{recordCount}</strong> record{recordCount !== 1 ? 's' : ''} will be written to the Delivery Hub and local database. Click the pencil icon to correct a value.</>
          : <>Review values before writing to the Delivery Hub. Click the pencil icon to correct a value.</>}
        {manualCount > 0 && <> <span className="field-card-manual-tag">Manually entered</span> fields were filled in by the SME.</>}
        {skippedCount > 0 && <> Greyed-out fields were skipped and will be stored as not available.</>}
      </p>

      {multi && (
        <>
          {mixed && (
            <div className="batch-warning">
              <i className="ti ti-alert-triangle batch-warning-icon" aria-hidden="true" />
              <span>
                The selected files span different metadata. Confirm you want to combine them into one annual aggregate before storing it.
              </span>
            </div>
          )}

          <label className="batch-aggregate-toggle">
            <input
              type="checkbox"
              checked={storeAggregate}
              onChange={e => onToggleAggregate(e.target.checked)}
            />
            <span>Store the combined annual aggregate as its own record{mixed ? ' (review the warning above)' : ''}</span>
          </label>

          <button
            className="files-drafts-toggle"
            onClick={() => setShowFiles(s => !s)}
            aria-expanded={showFiles}
          >
            <i className={`ti ti-chevron-${showFiles ? 'down' : 'right'}`} aria-hidden="true" />
            Per-file breakdown ({active.length})
          </button>
          {showFiles && (
            <div className="batch-file-list">
              {active.map((r, i) => (
                <div className="batch-file-row" key={i}>
                  <div className="batch-file-name">
                    <i className="ti ti-file-description" aria-hidden="true" /> {r.fileMeta?.name || `File ${i + 1}`}
                  </div>
                  <div className="batch-file-fields">
                    {r.finalFields.map(f => (
                      <span className="batch-file-field" key={f.label}>
                        <span className="batch-file-field-label">{f.label.split(' ')[0]}</span>
                        <strong>{f.value ?? '—'}</strong>
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
          <label className="field-label store-what-label">Combined annual total</label>
        </>
      )}

      <div className="field-cards">
        {sourceFields.map(f => (
          <FieldCard
            key={f.label}
            field={f}
            currentValue={editValues[f.label]}
            isEditing={editingLabel === f.label}
            onStartEdit={f.flag === 'SME skipped — data not available' ? () => {} : setEditingLabel}
            onCommit={commitEdit}
            onKeyDown={handleKeyDown}
          />
        ))}
      </div>

      <label className="field-label store-what-label">What gets stored</label>
      <div className="store-grid">
        {[
          { icon: 'ti-table',            title: multi ? `${recordCount} ROI records` : 'ROI values', sub: 'Delivery Hub · roi_metrics' },
          { icon: 'ti-shield-check',     title: 'Audit record',    sub: 'Local Database · audit_events' },
          { icon: 'ti-file-spreadsheet', title: 'Source file ref', sub: multi ? `${active.length} file${active.length !== 1 ? 's' : ''}` : (active[0]?.fileMeta?.name || '—') },
          { icon: 'ti-user-check',       title: 'SME checkpoint',  sub: `Approved · ${smeName || '—'}` },
        ].map(t => (
          <div className="store-tile" key={t.title}>
            <i className={`ti ${t.icon} store-tile-icon`} aria-hidden="true" />
            <div>
              <div className="store-tile-title">{t.title}</div>
              <div className="store-tile-sub">{t.sub}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="btn-row">
        <button className="btn ghost" onClick={onBack}>
          <i className="ti ti-arrow-left" aria-hidden="true" /> Back
        </button>
        <button className="btn primary" onClick={handleSave}>
          Save All &amp; Done <i className="ti ti-arrow-right" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

export { ScreenExtract, BatchExtract, FileReview, ScreenStore, ScreenCompare, CompareRow, FieldCard, PublisherField, BLANK_FIELDS, ROI_FIELD_META, buildClaudeFields };
