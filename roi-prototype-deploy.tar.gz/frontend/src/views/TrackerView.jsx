import React, { useState, useEffect, useMemo, useRef } from 'react';
import Badge from '../components/Badge';
import { BASE, getRecords, downloadRecordsAsXlsx, updateRecord, getAuditLog, getFields, generateExecutiveSummary, saveExecutiveSummary, deleteRecord } from '../services/api';
import ExecutiveSummaryReport from '../components/ExecutiveSummaryReport';
import SendToHubModal from '../components/SendToHubModal';

// ─── Field catalog ──────────────────────────────────────────────────────────
// Single source of truth lives in the backend (models/field_catalog.py) and is
// fetched once from GET /api/fields. The Tracker renders only `ui_visible`
// fields, marks `editable` ones inline-editable, and uses `notes` for column
// tooltips — so the column definitions are never duplicated here.
let _fieldsCache = null;

function useFields() {
  const [catalog, setCatalog] = useState(_fieldsCache || []);
  const [loading, setLoading] = useState(!_fieldsCache);

  useEffect(() => {
    if (_fieldsCache) return;
    let alive = true;
    getFields()
      .then(f => { _fieldsCache = Array.isArray(f) ? f : []; if (alive) setCatalog(_fieldsCache); })
      .catch(() => { if (alive) setCatalog([]); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, []);

  return useMemo(() => ({
    catalog,
    loading,
    columns:     catalog.filter(f => f.ui_visible),
    colByKey:    Object.fromEntries(catalog.map(f => [f.key, f])),
    provMetrics: catalog.filter(f => f.provenance).map(f => [f.key, f.label]),
  }), [catalog, loading]);
}

const COL_STORAGE = 'domosapiens.tracker.columns';

// Sentinel for a filter condition that searches across every field.
const ANY_FIELD = '__any__';

// Build a CSV string from rows + columns, then trigger a browser download.
// Used by "Export view" so the file mirrors exactly what's on screen — the
// current search, filters, and visible/ordered columns. The leading BOM keeps
// Excel happy with UTF-8.
function downloadCsv(filename, columns, rows) {
  const esc = (v) => {
    const s = v == null ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const cellValue = (r, col) => (col.key === 'confidence' ? r.confidence : r[col.key]);
  const header = columns.map(c => esc(c.label)).join(',');
  const lines = rows.map(r => columns.map(c => esc(cellValue(r, c))).join(','));
  const csv = [header, ...lines].join('\n');
  const blob = new Blob([`﻿${csv}`], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function loadColPrefs(allKeys) {
  try {
    const raw = localStorage.getItem(COL_STORAGE);
    if (raw) {
      const p = JSON.parse(raw);
      // Reconcile saved prefs with the current column set (add new, drop gone).
      const order = (p.order || []).filter(k => allKeys.includes(k));
      // Insert new keys at their catalog position, not just appended at the end.
      for (let i = 0; i < allKeys.length; i++) {
        const k = allKeys[i];
        if (!order.includes(k)) {
          const nextIdx = order.findIndex(ok => allKeys.indexOf(ok) > i);
          if (nextIdx === -1) order.push(k);
          else order.splice(nextIdx, 0, k);
        }
      }
      const hidden = (p.hidden || []).filter(k => allKeys.includes(k));
      return { order, hidden };
    }
  } catch { /* ignore corrupt prefs */ }
  return { order: allKeys, hidden: [] };
}

const fmtAmount = (n) => {
  if (n == null || n === '') return '—';
  const num = Number(String(n).replace(/[$,\s]/g, ''));
  return Number.isNaN(num) ? String(n) : `$${num.toLocaleString()}`;
};
const confColor = (c) => (c >= 90 ? 'green' : c >= 75 ? 'amber' : 'red');
// Bucket a raw confidence % into a plain-language category for display.
const confLabel = (c) => (c >= 90 ? 'High' : c >= 75 ? 'Medium' : 'Low');

// ─── Columns menu (show/hide) ──────────────────────────────────────────────────
function ColumnsMenu({ columns, prefs, onToggle, onReset }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <button className="btn ghost small" onClick={() => setOpen(o => !o)}>
        <i className="ti ti-columns-3" aria-hidden="true" /> Columns
      </button>
      {open && (
        <div style={{
          position: 'absolute', right: 0, top: '110%', zIndex: 30,
          background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10,
          boxShadow: '0 8px 24px rgba(0,0,0,0.12)', padding: 10, minWidth: 240,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8, display: 'flex', justifyContent: 'space-between' }}>
            <span>Show columns</span>
            <button onClick={onReset} style={{ border: 'none', background: 'none', color: 'var(--blue)', fontSize: 11, cursor: 'pointer', fontWeight: 600 }}>Reset</button>
          </div>
          {columns.map(c => (
            <label key={c.key} title={c.notes || ''} style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: 8, padding: '4px 2px', fontSize: 13, cursor: 'pointer', textAlign: 'left' }}>
              <input
                type="checkbox"
                checked={!prefs.hidden.includes(c.key)}
                onChange={() => onToggle(c.key)}
                style={{ width: 'auto', flexShrink: 0, margin: 0, cursor: 'pointer' }}
              />
              <span style={{ flex: 1 }}>{c.label}</span>
            </label>
          ))}
          <div style={{ fontSize: 11, color: 'var(--text-faint)', marginTop: 8, borderTop: '1px solid var(--border)', paddingTop: 6 }}>
            Tip: drag a column header to reorder.
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Executive Summary Drawer ─────────────────────────────────────────────────
function ExecSummaryDrawer({ record, onClose }) {
  const summary  = record?.executive_summary || null;
  const printRef = useRef(null);

  const handleDownloadPDF = () => {
    import('html2pdf.js').then(mod => {
      const html2pdf = mod.default;
      const name = [record.client_scope_name, record.publisher].filter(Boolean).join('_') || 'ROI';
      html2pdf()
        .set({
          margin: [12, 12, 12, 12],
          filename: `${name}_Executive_Summary.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
          pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
        })
        .from(printRef.current)
        .save();
    });
  };

  if (!record) return null;

  const subtitle = [record.client_scope_name, record.publisher].filter(Boolean).join(' · ');

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0, background: 'rgba(0,25,65,0.45)',
          zIndex: 200, backdropFilter: 'blur(2px)',
        }}
      />

      {/* Drawer */}
      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0,
        width: 'min(780px, 92vw)',
        background: 'var(--bg)',
        zIndex: 201,
        display: 'flex', flexDirection: 'column',
        boxShadow: '-8px 0 40px rgba(0,0,0,0.25)',
        animation: 'slideInRight 0.25s ease',
      }}>
        {/* Drawer header */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '16px 24px', borderBottom: '1px solid var(--border)',
          background: 'var(--surface)', flexShrink: 0,
        }}>
          <i className="ti ti-file-description" style={{ fontSize: 20, color: 'var(--blue)' }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--navy)' }}>Executive Summary</div>
            {subtitle && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{subtitle}</div>}
          </div>
          <button
            onClick={handleDownloadPDF}
            disabled={!summary}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: summary ? 'var(--blue)' : 'var(--border)',
              color: '#fff', border: 'none', borderRadius: 8,
              padding: '7px 14px', fontSize: 12, fontWeight: 600, cursor: summary ? 'pointer' : 'not-allowed',
            }}
          >
            <i className="ti ti-file-type-pdf" /> Download PDF
          </button>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', fontSize: 22, color: 'var(--text-muted)', cursor: 'pointer', lineHeight: 1 }}
          >
            <i className="ti ti-x" />
          </button>
        </div>

        {/* Drawer body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
          {summary ? (
            <ExecutiveSummaryReport
              summary={summary}
              subtitle={subtitle}
              client={record.client_scope_name || ''}
              publisher={record.publisher || ''}
              innerRef={printRef}
            />
          ) : (
            <div style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              justifyContent: 'center', height: 240, gap: 14, color: 'var(--text-muted)',
              textAlign: 'center',
            }}>
              <i className="ti ti-file-off" style={{ fontSize: 40, opacity: 0.35 }} />
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6, color: 'var(--navy)' }}>
                  No executive summary saved yet
                </div>
                <div style={{ fontSize: 13 }}>
                  Complete the full extraction flow for this record —<br />
                  the summary is generated and saved automatically at the Done step.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ─── Tab: ROI Data (editable) ──────────────────────────────────────────────────
function TabROIData({ onSendToDashboards }) {
  const { catalog, columns, colByKey, loading: fieldsLoading } = useFields();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [edits, setEdits]     = useState({});        // { recordId: { field: stringValue } }
  const [editingCell, setEditingCell] = useState(null); // { rid, key }
  const [colPrefs, setColPrefs] = useState({ order: [], hidden: [] });
  const [note, setNote]   = useState('');
  const [editor, setEditor] = useState('');
  const [saving, setSaving] = useState(false);
  const [summaryRecord, setSummaryRecord] = useState(null);
  const [generating, setGenerating] = useState(null); // record_id being generated
  const [deleteTarget, setDeleteTarget] = useState(null); // { record_id, client }
  const [hubTarget, setHubTarget] = useState(null); // record being sent to the delivery hub
  const [deleteReason, setDeleteReason] = useState('');
  const [deleteError, setDeleteError] = useState(false);
  // Filter builder: a list of { field, query } conditions, AND-ed together.
  // field === ANY_FIELD searches across every field on the record. A trailing
  // blank row is kept so a new condition appears as soon as one is filled in.
  const [conditions, setConditions] = useState([{ field: ANY_FIELD, query: '' }]);
  const dragKey = useRef(null);

  const load = () => getRecords()
    .then(data => setRecords(Array.isArray(data) ? data : []))
    .catch(() => setRecords([]))
    .finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  // Column prefs depend on the fetched catalog, so load them once it arrives.
  const colKeySig = columns.map(c => c.key).join(',');
  useEffect(() => {
    if (columns.length) setColPrefs(loadColPrefs(columns.map(c => c.key)));
  }, [colKeySig]); // eslint-disable-line react-hooks/exhaustive-deps

  const recById = useMemo(() => Object.fromEntries(records.map(r => [r.record_id, r])), [records]);

  const visibleCols = useMemo(
    () => colPrefs.order.map(k => colByKey[k]).filter(c => c && !colPrefs.hidden.includes(c.key)),
    [colPrefs, colByKey],
  );

  // Field choices for the left-hand selector: "Any field" + every catalog field
  // (including ones hidden from the table), so you can filter on anything.
  const fieldChoices = useMemo(
    () => [{ key: ANY_FIELD, label: 'Any field' }, ...catalog.map(f => ({ key: f.key, label: f.label }))],
    [catalog],
  );

  // The on-screen rows: records that satisfy EVERY non-empty condition (AND).
  // A condition matches when the chosen field's value contains the typed text;
  // "Any field" matches across all fields (including nested provenance).
  const filteredRecords = useMemo(() => {
    const haystack = (r) => Object.values(r)
      .map(v => (v != null && typeof v === 'object' ? JSON.stringify(v) : String(v ?? '')))
      .join(' ')
      .toLowerCase();
    const active = conditions.filter(c => c.query.trim());
    if (!active.length) return records;
    return records.filter(r => active.every(c => {
      const q = c.query.trim().toLowerCase();
      if (c.field === ANY_FIELD) return haystack(r).includes(q);
      const cell = c.field === 'confidence' ? r.confidence : r[c.field];
      return String(cell ?? '').toLowerCase().includes(q);
    }));
  }, [records, conditions]);

  const activeFilterCount = conditions.filter(c => c.query.trim()).length;

  // Keep exactly one trailing blank row so a fresh condition is always available.
  const withTrailingBlank = (rows) => {
    const last = rows[rows.length - 1];
    return last && last.query.trim() ? [...rows, { field: ANY_FIELD, query: '' }] : rows;
  };
  const setCondition = (i, patch) => setConditions(prev =>
    withTrailingBlank(prev.map((c, idx) => (idx === i ? { ...c, ...patch } : c))));
  const addCondition = () => setConditions(prev => {
    const last = prev[prev.length - 1];
    return last && !last.query.trim() ? prev : [...prev, { field: ANY_FIELD, query: '' }];
  });
  const removeCondition = (i) => setConditions(prev => {
    const next = prev.filter((_, idx) => idx !== i);
    return withTrailingBlank(next.length ? next : [{ field: ANY_FIELD, query: '' }]);
  });
  const clearFilters = () => setConditions([{ field: ANY_FIELD, query: '' }]);

  const exportView = () => downloadCsv(
    `tracker_view_${new Date().toISOString().slice(0, 10)}.csv`,
    visibleCols,
    filteredRecords,
  );

  const persistCols = (next) => {
    setColPrefs(next);
    try { localStorage.setItem(COL_STORAGE, JSON.stringify(next)); } catch { /* quota */ }
  };
  const toggleHidden = (key) => persistCols({
    ...colPrefs,
    hidden: colPrefs.hidden.includes(key) ? colPrefs.hidden.filter(k => k !== key) : [...colPrefs.hidden, key],
  });
  const resetCols = () => persistCols({ order: columns.map(c => c.key), hidden: [] });
  const reorder = (fromKey, toKey) => {
    if (!fromKey || !toKey || fromKey === toKey) return;
    const order = [...colPrefs.order];
    const fi = order.indexOf(fromKey), ti = order.indexOf(toKey);
    if (fi < 0 || ti < 0) return;
    order.splice(fi, 1);
    order.splice(ti, 0, fromKey);
    persistCols({ ...colPrefs, order });
  };

  const cellRaw = (rid, key) => {
    const e = edits[rid];
    return e && key in e ? e[key] : recById[rid]?.[key];
  };
  const isEdited = (rid, key) => {
    const e = edits[rid];
    if (!e || !(key in e)) return false;
    return String(e[key] ?? '') !== String(recById[rid]?.[key] ?? '');
  };
  const setEdit = (rid, key, value) => setEdits(prev => ({ ...prev, [rid]: { ...(prev[rid] || {}), [key]: value } }));
  const revertCell = (rid, key) => setEdits(prev => {
    const fm = { ...(prev[rid] || {}) };
    delete fm[key];
    const next = { ...prev };
    if (Object.keys(fm).length) next[rid] = fm; else delete next[rid];
    return next;
  });

  const changeCount = useMemo(() => {
    let n = 0;
    for (const [rid, fm] of Object.entries(edits))
      for (const k of Object.keys(fm)) if (isEdited(rid, k)) n++;
    return n;
  }, [edits, records]);

  const discard = () => { setEdits({}); setNote(''); setEditingCell(null); };

  const handleSave = async () => {
    setSaving(true);
    try {
      for (const [rid, fm] of Object.entries(edits)) {
        const changes = {};
        for (const [k, v] of Object.entries(fm)) {
          if (!isEdited(rid, k)) continue;
          const col = colByKey[k];
          let parsed = v;
          if (col?.type === 'num') {
            const s = String(v).replace(/[$,\s]/g, '');
            if (s === '') { parsed = null; }
            else { parsed = Number(s); if (Number.isNaN(parsed)) continue; }
          }
          changes[k] = parsed;
        }
        if (Object.keys(changes).length) {
          await updateRecord(rid, { changes, user: editor, note });
        }
      }
      await load();
      discard();
    } catch (e) {
      console.error('[Tracker] save failed:', e);
      alert(`Save failed: ${e.message}`);
    } finally {
      setSaving(false);
    }
  };

  const renderCell = (record, col) => {
    const rid = record.record_id;
    const editing = editingCell && editingCell.rid === rid && editingCell.key === col.key;
    const edited = isEdited(rid, col.key);
    const raw = cellRaw(rid, col.key);

    if (col.editable) {
      if (editing) {
        return (
          <input
            autoFocus
            defaultValue={raw ?? ''}
            className="cell-input"
            onChange={(e) => setEdit(rid, col.key, e.target.value)}
            onBlur={() => setEditingCell(null)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') { e.currentTarget.blur(); }
              if (e.key === 'Escape') { revertCell(rid, col.key); setEditingCell(null); }
            }}
            style={{ width: '100%', font: 'inherit', padding: '2px 4px', border: '1px solid var(--blue)', borderRadius: 4, textAlign: 'right' }}
          />
        );
      }
      return (
        <span
          onClick={() => setEditingCell({ rid, key: col.key })}
          title="Click to edit"
          style={{
            display: 'block', cursor: 'pointer', borderRadius: 4, padding: '2px 4px', textAlign: 'right',
            background: edited ? 'rgba(255,173,0,0.18)' : 'transparent',
            outline: edited ? '1px solid var(--gold)' : 'none',
          }}
        >
          {edited && <i className="ti ti-point-filled" style={{ color: 'var(--gold)', fontSize: 10 }} aria-hidden="true" />}
          {fmtAmount(raw)}
        </span>
      );
    }

    switch (col.type) {
      case 'conf':
        return record.confidence != null ? <Badge color={confColor(record.confidence)}>{confLabel(record.confidence)}</Badge> : '—';
      case 'num':
        return fmtAmount(record[col.key]);
      case 'file':
        return record.stored_name
          ? <a href={`${BASE}/uploads/${record.stored_name}`} target="_blank" rel="noreferrer" style={{ color: 'var(--blue)' }}>{record.source_file || record.stored_name}</a>
          : <span style={{ color: 'var(--text-muted)' }}>{record.source_file || '—'}</span>;
      default:
        return record[col.key] ?? '—';
    }
  };

  const handleDeleteConfirm = async () => {
    const reason = deleteReason.trim().toLowerCase();
    if (reason !== 'duplicate' && reason !== 'error') {
      setDeleteError(true);
      return;
    }
    try {
      await deleteRecord(deleteTarget.record_id, reason);
      setRecords(prev => prev.filter(r => r.record_id !== deleteTarget.record_id));
      setDeleteTarget(null);
      setDeleteReason('');
      setDeleteError(false);
    } catch {
      setDeleteError(true);
    }
  };

  const handleGenerate = async (r) => {
    setGenerating(r.record_id);
    try {
      const data = await generateExecutiveSummary({
        client:               r.client_scope_name,
        publisher:            r.publisher,
        identified_risk:      r.identified_risk,
        id_cost_avoidance:    r.id_cost_avoidance,
        acc_cost_avoidance:   r.acc_cost_avoidance,
        id_cost_optimization: r.id_cost_optimization,
        acc_cost_optimization:r.acc_cost_optimization,
        realized_savings:     r.realized_savings,
        contract_spend:       r.contract_spend,
        confidence:           r.confidence,
        stored_name:          r.stored_name,
      });
      const identifier = r.stored_name || r.source_file;
      if (identifier) await saveExecutiveSummary(identifier, data).catch(() => {});
      // Update local state so drawer opens immediately
      setRecords(prev => prev.map(rec =>
        rec.record_id === r.record_id ? { ...rec, executive_summary: data } : rec
      ));
      setSummaryRecord({ ...r, executive_summary: data });
    } catch (e) {
      alert('Could not generate summary. Check your API key.');
    } finally {
      setGenerating(null);
    }
  };

  if (loading || fieldsLoading) return <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Loading records…</p>;

  const totalCols = visibleCols.length + 4; // index + exec summary + hub + delete

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, gap: 12 }}>
        <p style={{ fontSize: 12, color: 'var(--blue)', margin: 0 }}>
          <i className="ti ti-info-circle" aria-hidden="true" /> Click a value to edit it · source slide &amp; confidence live on the <strong>Field Provenance</strong> tab
        </p>
        <ColumnsMenu columns={columns} prefs={colPrefs} onToggle={toggleHidden} onReset={resetCols} />
      </div>

      <div style={{ marginBottom: 10 }}>
        {conditions.map((c, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <select
              value={c.field}
              onChange={(e) => setCondition(i, { field: e.target.value })}
              title="Field to filter on"
              style={{ flex: '0 0 200px', padding: '6px 10px', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, background: 'var(--surface)', cursor: 'pointer' }}
            >
              {fieldChoices.map(f => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
            <div style={{ position: 'relative', flex: '1 1 220px', minWidth: 160 }}>
              <i className="ti ti-search" aria-hidden="true" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-faint)', fontSize: 14 }} />
              <input
                placeholder={c.field === ANY_FIELD ? 'Search any field…' : `${fieldChoices.find(f => f.key === c.field)?.label || ''} contains…`}
                value={c.query}
                onChange={(e) => setCondition(i, { query: e.target.value })}
                style={{ width: '100%', padding: '6px 10px 6px 30px', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }}
              />
            </div>
            <button
              className="btn ghost small"
              onClick={() => removeCondition(i)}
              disabled={conditions.length === 1 && !c.query.trim()}
              title="Remove this filter"
              style={{ flex: '0 0 auto' }}
            >
              <i className="ti ti-x" aria-hidden="true" />
            </button>
          </div>
        ))}

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
          <button className="btn ghost small" onClick={addCondition}>
            <i className="ti ti-plus" aria-hidden="true" /> Add filter
          </button>
          {activeFilterCount > 0 && (
            <button className="btn ghost small" onClick={clearFilters} title="Clear all filters">
              <i className="ti ti-filter-off" aria-hidden="true" /> Clear all
            </button>
          )}
          <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 'auto' }}>
            {activeFilterCount > 0
              ? <>Showing <strong style={{ color: 'var(--text)' }}>{filteredRecords.length}</strong> of {records.length}</>
              : <>{records.length} record{records.length !== 1 ? 's' : ''}</>}
          </span>
          <button className="btn ghost small" onClick={exportView} disabled={filteredRecords.length === 0} title="Export only the rows & columns currently shown (active filters + visible columns) to CSV">
            <i className="ti ti-file-export" aria-hidden="true" /> Export filtered view ({filteredRecords.length})
          </button>
          {onSendToDashboards && (
            <button
              className="btn ghost small"
              onClick={() => onSendToDashboards(filteredRecords)}
              disabled={filteredRecords.length === 0}
              title="Open the Dashboards builder scoped to exactly the rows currently shown (active filters)"
            >
              <i className="ti ti-chart-histogram" aria-hidden="true" /> Send to Dashboards ({filteredRecords.length})
            </button>
          )}
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ width: 30 }}>#</th>
                {visibleCols.map(col => (
                  <th
                    key={col.key}
                    draggable
                    onDragStart={() => { dragKey.current = col.key; }}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() => { reorder(dragKey.current, col.key); dragKey.current = null; }}
                    style={{ cursor: 'grab', whiteSpace: 'nowrap' }}
                    title={col.notes ? `${col.notes} · Drag to reorder` : 'Drag to reorder'}
                  >
                    {col.label}{col.editable && <i className="ti ti-pencil" style={{ fontSize: 11, marginLeft: 4, color: 'var(--text-faint)' }} aria-hidden="true" />}
                  </th>
                ))}
                <th>Exec. Summary</th>
                <th style={{ width: 44 }}>Hub</th>
                <th style={{ width: 40 }}></th>
              </tr>
            </thead>
            <tbody>
              {records.length === 0 ? (
                <tr><td colSpan={totalCols} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 24 }}>No records yet. Complete an extraction to see data here.</td></tr>
              ) : filteredRecords.length === 0 ? (
                <tr><td colSpan={totalCols} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 24 }}>No records match your search or filters. <button onClick={clearFilters} style={{ border: 'none', background: 'none', color: 'var(--blue)', cursor: 'pointer', fontWeight: 600 }}>Clear</button></td></tr>
              ) : filteredRecords.map((r, i) => (
                <tr key={r.record_id || i} className={edits[r.record_id] ? 'row-edited' : ''}>
                  <td style={{ color: 'var(--text-faint)' }}>{i + 1}</td>
                  {visibleCols.map(col => (
                    <td key={col.key} style={{ fontSize: col.type === 'file' ? 11 : undefined }}>
                      {renderCell(r, col)}
                    </td>
                  ))}
                  <td onClick={e => e.stopPropagation()}>
                    {r.executive_summary ? (
                      <button
                        onClick={() => setSummaryRecord(r)}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          background: 'var(--blue-pale)', color: 'var(--blue)',
                          border: '1.5px solid var(--blue)', borderRadius: 8,
                          padding: '4px 10px', fontSize: 11, fontWeight: 600, cursor: 'pointer',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <i className="ti ti-file-description" /> View
                      </button>
                    ) : (
                      <button
                        onClick={() => handleGenerate(r)}
                        disabled={generating === r.record_id}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          background: generating === r.record_id ? 'var(--surface-3)' : 'var(--gold-pale)',
                          color: generating === r.record_id ? 'var(--text-muted)' : 'var(--gold-text)',
                          border: `1.5px solid ${generating === r.record_id ? 'var(--border)' : 'var(--gold)'}`,
                          borderRadius: 8, padding: '4px 10px', fontSize: 11, fontWeight: 600,
                          cursor: generating === r.record_id ? 'not-allowed' : 'pointer',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {generating === r.record_id
                          ? <><i className="ti ti-loader-2" style={{ animation: 'spin 1s linear infinite' }} /> Generating…</>
                          : <><i className="ti ti-sparkles" /> Generate</>}
                      </button>
                    )}
                  </td>
                  <td onClick={e => e.stopPropagation()} style={{ textAlign: 'center' }}>
                    <button
                      onClick={() => setHubTarget(r)}
                      title="Send this record to the Delivery Hub (roi_metrics)"
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        color: 'var(--text-faint)', padding: '2px 6px', borderRadius: 6,
                        fontSize: 15, lineHeight: 1,
                        transition: 'color 0.15s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.color = 'var(--blue)'}
                      onMouseLeave={e => e.currentTarget.style.color = 'var(--text-faint)'}
                    >
                      <i className="ti ti-send" />
                    </button>
                  </td>
                  <td onClick={e => e.stopPropagation()} style={{ textAlign: 'center' }}>
                    <button
                      onClick={() => { setDeleteTarget(r); setDeleteReason(''); setDeleteError(false); }}
                      title="Delete record"
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        color: 'var(--text-faint)', padding: '2px 6px', borderRadius: 6,
                        fontSize: 15, lineHeight: 1,
                        transition: 'color 0.15s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.color = 'var(--red)'}
                      onMouseLeave={e => e.currentTarget.style.color = 'var(--text-faint)'}
                    >
                      <i className="ti ti-trash" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {changeCount > 0 && (
        <div style={{
          position: 'sticky', bottom: 0, marginTop: 12, zIndex: 20,
          background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12,
          boxShadow: '0 -4px 16px rgba(0,0,0,0.08)', padding: 12,
          display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap',
        }}>
          <Badge color="gold">{changeCount} unsaved change{changeCount !== 1 ? 's' : ''}</Badge>
          <input
            placeholder="Your name (SME)"
            value={editor}
            onChange={(e) => setEditor(e.target.value)}
            style={{ width: 170, flex: '0 0 170px', padding: '6px 10px', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }}
          />
          <input
            placeholder="Note — why? (e.g. client confirmed via stakeholder X)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            style={{ width: 'auto', flex: '1 1 260px', minWidth: 220, padding: '6px 10px', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }}
          />
          <button className="btn ghost" onClick={discard} disabled={saving}>Discard</button>
          <button className="btn primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving…' : <>Review &amp; save {changeCount} change{changeCount !== 1 ? 's' : ''} <i className="ti ti-device-floppy" aria-hidden="true" /></>}
          </button>
        </div>
      )}

      {summaryRecord && (
        <ExecSummaryDrawer record={summaryRecord} onClose={() => setSummaryRecord(null)} />
      )}

      {hubTarget && (
        <SendToHubModal record={hubTarget} onClose={() => setHubTarget(null)} />
      )}

      {/* Delete confirmation modal */}
      {deleteTarget && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 1000,
          background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => { setDeleteTarget(null); setDeleteError(false); }}>
          <div style={{
            background: '#ffffff', borderRadius: 14, padding: '28px 32px', width: 380,
            boxShadow: '0 8px 40px rgba(0,0,0,0.4)', display: 'flex', flexDirection: 'column', gap: 16,
          }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <i className="ti ti-trash" style={{ color: 'var(--red)', fontSize: 20 }} />
              <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--navy)' }}>Delete Record</span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              <strong>{deleteTarget.client_scope_name || deleteTarget.record_id}</strong> will be permanently removed. Select a reason:
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              {['duplicate', 'error'].map(opt => (
                <button
                  key={opt}
                  onClick={() => { setDeleteReason(opt); setDeleteError(false); }}
                  style={{
                    flex: 1, padding: '8px 0', borderRadius: 8, fontWeight: 600, fontSize: 13,
                    cursor: 'pointer', border: '2px solid',
                    borderColor: deleteReason === opt ? 'var(--red)' : 'var(--border)',
                    background: deleteReason === opt ? 'var(--red)' : 'var(--surface-2)',
                    color: deleteReason === opt ? '#fff' : 'var(--text)',
                    transition: 'all 0.15s',
                  }}
                >
                  {opt === 'duplicate' ? '🔁 Duplicate' : '⚠️ Error'}
                </button>
              ))}
            </div>
            {deleteError && (
              <div style={{ background: 'var(--red-pale,#fff0f0)', border: '1px solid var(--red)', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: 'var(--red)', fontWeight: 600 }}>
                Could not delete — please select a reason and try again.
              </div>
            )}
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => { setDeleteTarget(null); setDeleteError(false); }}
                style={{ padding: '7px 18px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--surface-2)', color: 'var(--text)', cursor: 'pointer', fontWeight: 600, fontSize: 13 }}
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                style={{ padding: '7px 18px', borderRadius: 8, border: 'none', background: 'var(--red)', color: '#fff', cursor: 'pointer', fontWeight: 600, fontSize: 13 }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ─── Tab: Audit Log (append-only event history) ─────────────────────────────────
function TabAuditLog() {
  const [events, setEvents]   = useState([]);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getAuditLog(), getRecords()])
      .then(([ev, rec]) => {
        setEvents(Array.isArray(ev) ? ev : []);
        setRecords(Array.isArray(rec) ? rec : []);
      })
      .catch(() => { setEvents([]); setRecords([]); })
      .finally(() => setLoading(false));
  }, []);

  const recById = useMemo(() => Object.fromEntries(records.map(r => [r.record_id, r])), [records]);
  const ordered = useMemo(
    () => [...events].sort((a, b) => String(b.timestamp || '').localeCompare(String(a.timestamp || ''))),
    [events],
  );
  const actionColor = (a) => (a === 'edit' ? 'amber' : a === 'create' ? 'green' : 'blue');

  if (loading) return <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Loading…</p>;

  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr><th>Timestamp</th><th>Scope</th><th>Publisher</th><th>Action</th><th>Field</th><th>Change</th><th>User</th><th>Note</th></tr>
          </thead>
          <tbody>
            {ordered.length === 0 ? (
              <tr><td colSpan={8} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 24 }}>No audit entries yet.</td></tr>
            ) : ordered.map((e) => {
              const rec = recById[e.record_id] || {};
              return (
                <tr key={e.event_id}>
                  <td style={{ color: 'var(--text-faint)' }}>{e.timestamp ? new Date(e.timestamp).toLocaleString() : '—'}</td>
                  <td>{rec.client_scope_name || '—'}</td>
                  <td>{rec.publisher || '—'}</td>
                  <td><Badge color={actionColor(e.action)}>{e.action}</Badge></td>
                  <td style={{ fontSize: 12 }}>{e.field || '—'}</td>
                  <td style={{ fontSize: 12 }}>
                    {e.action === 'edit'
                      ? <span><span style={{ color: 'var(--text-muted)' }}>{fmtAmount(e.old_value)}</span> → <strong>{fmtAmount(e.new_value)}</strong></span>
                      : '—'}
                  </td>
                  <td>{e.user || '—'}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 11 }}>{e.note || '—'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Tab: Source Files ────────────────────────────────────────────────────────
function TabSourceFiles() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getRecords()
      .then(data => setRecords(Array.isArray(data) ? data : []))
      .catch(() => setRecords([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Loading…</p>;

  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr><th>Filename</th><th>Scope</th><th>Publisher</th><th>Start Date</th><th>End Date</th><th>Used on</th><th>SME</th></tr>
          </thead>
          <tbody>
            {records.length === 0 ? (
              <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 24 }}>No source files yet.</td></tr>
            ) : records.map((r, i) => (
              <tr key={r.record_id || i}>
                <td style={{ fontWeight: 500 }}>
                    {r.stored_name
                      ? <a href={`${BASE}/uploads/${r.stored_name}`} target="_blank" rel="noreferrer" style={{ color: 'var(--blue)' }}>{r.source_file || r.stored_name}</a>
                      : <span style={{ color: 'var(--text-muted)' }}>{r.source_file || '—'}</span>}
                  </td>
                <td>{r.client_scope_name}</td>
                <td>{r.publisher}</td>
                <td>{r.applicable_from || '—'}</td>
                <td>{r.applicable_to || '—'}</td>
                <td style={{ color: 'var(--text-faint)' }}>{r.saved_at ? new Date(r.saved_at).toLocaleDateString() : '—'}</td>
                <td>{r.sme || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Tab: Field Provenance ──────────────────────────────────────────────────
// In-app mirror of the Excel `Field_Provenance` sheet: one row per record×metric,
// with the source slide and confidence the value was extracted with.
function TabFieldProvenance() {
  const { provMetrics, loading: fieldsLoading } = useFields();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getRecords()
      .then(data => setRecords(Array.isArray(data) ? data : []))
      .catch(() => setRecords([]))
      .finally(() => setLoading(false));
  }, []);

  const rows = useMemo(() => {
    const out = [];
    for (const r of records) {
      const fm = r.field_meta || {};
      for (const [k, label] of provMetrics) {
        if (r[k] == null && !fm[k]) continue;
        const meta = fm[k] || {};
        out.push({
          record_id: r.record_id, client_scope_name: r.client_scope_name, publisher: r.publisher, applicable_from: r.applicable_from, applicable_to: r.applicable_to,
          metric: label, value: r[k],
          source_slide: meta.source_slide, confidence: meta.confidence,
          alternates: (meta.alternates || []).map(a => `${a.value} (${a.confidence}%)`).join(', '),
        });
      }
    }
    return out;
  }, [records, provMetrics]);

  if (loading || fieldsLoading) return <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Loading…</p>;

  return (
    <>
      <p style={{ fontSize: 12, color: 'var(--blue)', marginBottom: 10 }}>
        <i className="ti ti-info-circle" aria-hidden="true" /> One row per metric — exactly the <strong>Field_Provenance</strong> sheet in the Excel export. Sort/filter there for deep triage.
      </p>
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Record</th><th>Scope</th><th>Publisher</th><th>Start Date</th><th>End Date</th>
                <th>Metric</th><th>Value</th><th>Source slide</th><th>Confidence</th><th>Alternates</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr><td colSpan={9} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 24 }}>No provenance yet. Newly extracted records populate this automatically.</td></tr>
              ) : rows.map((row, i) => (
                <tr key={i}>
                  <td style={{ fontSize: 11, color: 'var(--text-faint)' }}>{row.record_id}</td>
                  <td>{row.client_scope_name}</td>
                  <td>{row.publisher}</td>
                  <td>{row.applicable_from || '—'}</td>
                  <td>{row.applicable_to || '—'}</td>
                  <td>{row.metric}</td>
                  <td>{fmtAmount(row.value)}</td>
                  <td style={{ textAlign: 'center' }}>{row.source_slide ?? '—'}</td>
                  <td>{row.confidence != null ? <Badge color={confColor(row.confidence)}>{confLabel(row.confidence)}</Badge> : '—'}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{row.alternates || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

// ─── TrackerView ──────────────────────────────────────────────────────────────
const TABS = [
  { id: 'data',       label: 'ROI Data'         },
  { id: 'provenance', label: 'Field Provenance' },
  { id: 'audit',      label: 'SME Audit Log'    },
  { id: 'sources',    label: 'Source Files'     },
];

export default function TrackerView({ onSendToDashboards }) {
  const [activeTab, setActiveTab] = useState('data');

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 4 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
          Stored in <strong style={{ color: 'var(--text)' }}>Client_ROI_Tracker.xlsx</strong> &nbsp;·&nbsp;
          3 sheets: <strong style={{ color: 'var(--text)' }}>All_ROI_Data</strong>,{' '}
          <strong style={{ color: 'var(--text)' }}>SME_Audit_Log</strong>,{' '}
          <strong style={{ color: 'var(--text)' }}>Field_Provenance</strong>
        </p>
        <button className="btn ghost small" onClick={downloadRecordsAsXlsx} title="Export ALL records (every column, all 4 sheets) as the full Domo-ready workbook"><i className="ti ti-table-export" aria-hidden="true" /> Export full raw (.xlsx)</button>
      </div>

      <div className="tab-bar">
        {TABS.map(t => (
          <button key={t.id} className={`tab-item ${activeTab === t.id ? 'active' : ''}`} onClick={() => setActiveTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'data'       && <TabROIData onSendToDashboards={onSendToDashboards} />}
      {activeTab === 'provenance' && <TabFieldProvenance />}
      {activeTab === 'audit'      && <TabAuditLog   />}
      {activeTab === 'sources'    && <TabSourceFiles />}
    </>
  );
}
