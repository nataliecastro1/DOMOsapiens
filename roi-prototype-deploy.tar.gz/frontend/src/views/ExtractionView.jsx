import React, { useState, useRef } from 'react';
import StepUpload from '../components/extraction/StepUpload';
import StepValidate from '../components/extraction/StepValidate';
import { FileReview, buildClaudeFields, ROI_FIELD_META } from '../components/extraction/StepReview';
import { ScreenDone } from '../components/extraction/StepDone';
import { extractROAR, extractFromFile, saveRecord } from '../services/api';
import { getHubContext } from '../services/hubContext';
import { buildRecord, buildScriptData, aggregateFinalFields, deriveCommonMeta } from '../components/extraction/helpers';
import { YEARS } from '../data';

// ─── Journey Bar ──────────────────────────────────────────────────────────────
const STEP_DEFS = [
  { label: 'Request',      icon: 'ti-adjustments-horizontal' },
  { label: 'SME Validate', icon: 'ti-user-check'             },
  { label: 'Review',       icon: 'ti-database'               },
  { label: 'Done',         icon: 'ti-circle-check'           },
];

const STEP_TO_BAR = [0, 1, 1, 2, 2, 2, 3];

function JourneyBar({ currentStep }) {
  return (
    <div id="journey-bar" className="journey-bar" role="list" aria-label="Extraction pipeline">
      {STEP_DEFS.map((step, i) => {
        const isDone   = i < currentStep;
        const isActive = i === currentStep;
        return (
          <React.Fragment key={i}>
            <div
              className={`journey-step ${isDone ? 'done' : ''} ${isActive ? 'active' : ''}`}
              role="listitem"
              aria-current={isActive ? 'step' : undefined}
              style={{ cursor: 'default' }}
            >
              <div className="journey-step-icon">
                {isDone
                  ? <i className="ti ti-check" aria-hidden="true" />
                  : <i className={`ti ${step.icon}`} aria-hidden="true" />
                }
              </div>
              <div className="journey-step-label">{step.label}</div>
            </div>
            {i < STEP_DEFS.length - 1 && (
              <div className={`journey-connector ${isDone ? 'done' : ''}`} aria-hidden="true" />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ─── ExtractionView ───────────────────────────────────────────────────────────
export default function ExtractionView({ onNav, loggedInUser = '', initialClient = '', initialPublisher = '', onOpenRecord }) {
  const [step, setStep]                         = useState(0);
  const [files, setFiles]                       = useState([]);
  const [currentFileIndex, setCurrentFileIndex] = useState(0);
  const [fileResults, setFileResults]           = useState([]);
  const [smeName, setSmeName]                   = useState('');
  const [aggregateFields, setAggregateFields]   = useState(null);
  const [filters, setFilters]                   = useState({});
  const [savedRecordId, setSavedRecordId]       = useState(null);
  const [fileStatuses, setFileStatuses]         = useState([]);
  const extractionCancelRef = useRef(false);
  const [duplicateRecord, setDuplicateRecord]   = useState(null);

  const [reqYear, setReqYear]           = useState('');
  const [reqClient, setReqClient]       = useState(initialClient);
  const [reqPublisher, setReqPublisher] = useState(initialPublisher);

  const startExtraction = (filesToExtract) => {
    extractionCancelRef.current = false;
    setFileStatuses(filesToExtract.map(() => 'pending'));
    setFileResults(filesToExtract.map(f => ({ fileMeta: f, extractedData: null, scriptData: null, finalFields: null, excluded: false })));

    (async () => {
      for (let i = 0; i < filesToExtract.length; i++) {
        if (extractionCancelRef.current) return;
        setFileStatuses(prev => prev.map((s, idx) => idx === i ? 'running' : s));

        const file = filesToExtract[i];
        let extractedData = null;
        let scriptData = null;
        const tasks = [];

        let scriptMeta = null;
        if (file?.file) {
          tasks.push(
            extractROAR(file.file)
              .then(roar => {
                scriptData = buildScriptData(roar);
                scriptMeta = {
                  month:     roar?.month     || null,
                  year:      roar?.year      || null,
                  currency:  roar?.currency  || null,
                  publisher: roar?.publisher || null,
                };
              })
              .catch(() => {})
          );
        }

        const fileRef = (file?.path || file?.id || file?.stored_name) ? file : (file?.name || '');
        tasks.push(
          extractFromFile(fileRef)
            .then(res => { extractedData = res.data || res; })
            .catch(() => {})
        );

        await Promise.all(tasks);
        if (extractionCancelRef.current) return;

        setFileResults(prev => prev.map((r, idx) =>
          idx === i ? { ...r, extractedData, scriptData, scriptMeta } : r
        ));
        setFileStatuses(prev => prev.map((s, idx) => idx === i ? 'done' : s));
      }
    })();
  };

  const handleFilesSelected = (picked) => {
    const arr = Array.isArray(picked) ? picked : [picked];
    setFiles(arr);
    setCurrentFileIndex(0);
    setStep(2);
  };

  const handleSMEConfirm = ({ smeName: n }) => {
    setSmeName(n);
    startExtraction(files);
    setStep(4);
  };

  const performSave = async (results) => {
    const agg = aggregateFinalFields(results);
    const sme = smeName || loggedInUser || '';
    const active = results.filter(r => !r.excluded && r.finalFields);
    const isMulti = active.length > 1;
    const cm = deriveCommonMeta(results);

    let primaryRecordId = null;

    if (!isMulti) {
      const only = active[0];
      const meta = { ...(only?.fileMeta || files[0] || {}), ...(only?.metaDetails || {}) };
      const saved = await saveRecord(buildRecord(meta, agg, sme, only?.scriptData))
        .catch(err => { console.error('[Store] saveRecord failed:', err); return null; });
      primaryRecordId = saved?.record_id || null;
    } else {
      const saved = await Promise.all(active.map(r =>
        saveRecord(buildRecord({ ...r.fileMeta, ...(r.metaDetails || {}) }, r.finalFields, sme, r.scriptData))
          .catch(err => { console.error('[Store] saveRecord failed:', err); return null; })
      ));
      primaryRecordId = saved[0]?.record_id || null;
      const aggRecord = buildRecord({ client: cm.client, publisher: cm.publisher, year: cm.year }, agg, sme);
      aggRecord.source_file = `Aggregate — ${cm.client || 'Multi-client'} ${cm.year || ''}`.trim();
      const aggSaved = await saveRecord(aggRecord)
        .catch(err => { console.error('[Store] aggregate saveRecord failed:', err); return null; });
      if (!primaryRecordId) primaryRecordId = aggSaved?.record_id || null;
    }

    setSavedRecordId(primaryRecordId);
    setAggregateFields(agg);
    setFileResults(results);
    setStep(6);
  };

  const advanceAfterFile = (results) => {
    const next = currentFileIndex + 1;
    if (next < results.length) {
      setFileResults(results);
      setCurrentFileIndex(next);
    } else {
      performSave(results);
    }
  };

  const handleFileConfirm = (resolvedFields, metaDetails) => {
    advanceAfterFile(
      fileResults.map((r, i) => i === currentFileIndex ? { ...r, finalFields: resolvedFields, metaDetails: metaDetails || {}, excluded: false } : r)
    );
  };

  const handleFileExclude = () => {
    advanceAfterFile(
      fileResults.map((r, i) => i === currentFileIndex ? { ...r, excluded: true, finalFields: null } : r)
    );
  };

  const commonMeta = deriveCommonMeta(fileResults);

  const activeResults = fileResults.filter(r => !r.excluded);
  const doneMeta = {
    client:      commonMeta.client,
    publisher:   commonMeta.publisher,
    year:        commonMeta.year,
    stored_name: activeResults[0]?.fileMeta?.stored_name || null,
    file_path:   activeResults[0]?.fileMeta?.file_path   || null,
    name:        activeResults.length > 1 ? `${activeResults.length} files` : (activeResults[0]?.fileMeta?.name || ''),
    record_id:   savedRecordId,
  };

  const screens = [
    <StepUpload  key={0} onNext={(f) => { setFilters(f); setStep(1); }} onUploaded={handleFilesSelected}
      year={reqYear} onYearChange={setReqYear}
      client={reqClient}
      publisher={reqPublisher}
      existingBatch={files}
      onRemoveExisting={(idx) => setFiles(prev => prev.filter((_, i) => i !== idx))}
      onOpenRecord={onOpenRecord}
      onDuplicateChange={setDuplicateRecord}
    />,
    null,
    <StepValidate key={2} selectedFile={files[0]} files={files} onConfirm={handleSMEConfirm} onBack={() => setStep(0)} defaultName={loggedInUser} isDuplicate={!!duplicateRecord} />,
    null,
    <FileReview
      key={`4-${currentFileIndex}`}
      fileResult={fileResults[currentFileIndex]}
      fileIndex={currentFileIndex}
      duplicateRecord={duplicateRecord}
      total={files.length}
      isLast={currentFileIndex === files.length - 1}
      onConfirm={handleFileConfirm}
      onExclude={handleFileExclude}
      onBack={() => setStep(2)}
      allStatuses={fileStatuses}
      files={files}
      smeName={smeName}
    />,
    null,
    <ScreenDone     key={6} finalFields={aggregateFields} selectedFile={doneMeta} onTracker={() => onNav('tracker')} onDashboards={(dashId) => onNav('dashboards', dashId)} loggedInUser={loggedInUser} onBack={() => setStep(4)} />,
  ];

  return (
    <>
      <JourneyBar currentStep={STEP_TO_BAR[step] ?? 0} />
      {screens[step]}
    </>
  );
}
